﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using DMBIndexerProV4;
using static DMBIndexerPro.ClassesDMB;

//This file represents many hours of trial and error in the pursuit of being able to read DMB's .dat files for the purpose of displaying "as played" stats from the game.
//If you use this file in conjunction with your own DMB utility, please recognize the hours spent putting this file together and give me credit for such.
//Charles Vantuyl

namespace DMBIndexerPro
{
    class RepositoryDMB   // : Interface1
    {
        int RC;
        int Ind;
        List<IDXONE> datlist = new List<IDXONE>();

        public IEnumerable<Masterplyr> MasterPlayer11(string path)//masterplyr file
        {
            List<Masterplyr> readList = new List<Masterplyr>();
            var mainpath = System.IO.Directory.GetParent(path).ToString();
            var sendpath = mainpath + "\\Mastplyr.IDX";
            GETIDX(sendpath);
            path = mainpath + "\\Mastplyr.dat";
            if (path != null && File.Exists(path))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        br.BaseStream.Position = Ind;
                        var Iter = RC * 100 + Ind;
                        while (br.BaseStream.Position < Iter)// 1400 bytes
                        {
                            readList.Add(new Masterplyr
                            {
                                ActFlag = br.ReadInt16(),//2
                                Exl1 = br.ReadByte(),//4
                                Exl2 = br.ReadByte(),//4
                                PlayerUID = br.ReadInt32(),//8
                                FName = br.ReadBytes(14),
                                LName = br.ReadBytes(16),//38
                                NName = br.ReadBytes(32),//70
                                BthYr = br.ReadInt16(),//72
                                BthMo = br.ReadByte(),
                                BthDa = br.ReadByte(),
                                DebutYr = br.ReadInt16(),
                                FinalYr = br.ReadInt16(),
                                PPos = br.ReadByte(),
                                Type = br.ReadByte(),
                                Bats = br.ReadByte(),
                                Thrw = br.ReadByte(),
                                ArmAngle = br.ReadByte(),
                                Velocity = br.ReadByte(),
                                Curve = br.ReadByte(),
                                CutFast = br.ReadByte(),
                                Change = br.ReadByte(),
                                Fastball = br.ReadByte(),
                                Forkball = br.ReadByte(),
                                Knuckler = br.ReadByte(),
                                Palmball = br.ReadByte(),
                                Screwball = br.ReadByte(),
                                Splitter = br.ReadByte(),
                                Sinker = br.ReadByte(),
                                Slider = br.ReadByte(),
                                Spitball = br.ReadByte(),
                                OutPitch = br.ReadByte(),
                                Style = br.ReadByte(),
                                Extra = br.ReadBytes(2),
                            });
                        }//while
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            return readList;
        }

        public IEnumerable<Masterplyr> MasterPlayer12(string path)//masterplyr file
        {
            List<Masterplyr> readList = new List<Masterplyr>();
            path = Directory.GetParent(path).ToString();
            path += "\\Mastplyr.dat";
            if (path != null && File.Exists(path))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        br.BaseStream.Position = 2400;
                        while (br.BaseStream.Position < br.BaseStream.Length - 100)
                        {
                            readList.Add(new Masterplyr
                            {
                                ActFlag = br.ReadInt16(),//2
                                Exl1 = br.ReadByte(),//4
                                Exl2 = br.ReadByte(),//4
                                PlayerUID = br.ReadInt32(),//8
                                FName = br.ReadBytes(14),
                                LName = br.ReadBytes(16),//38
                                NName = br.ReadBytes(32),//70
                                BthYr = br.ReadInt16(),//72
                                BthMo = br.ReadByte(),
                                BthDa = br.ReadByte(),
                                DebutYr = br.ReadInt16(),
                                FinalYr = br.ReadInt16(),
                                PPos = br.ReadByte(),
                                Type = br.ReadByte(),
                                Bats = br.ReadByte(),
                                Thrw = br.ReadByte(),
                                ArmAngle = br.ReadByte(),
                                Velocity = br.ReadByte(),
                                Curve = br.ReadByte(),
                                CutFast = br.ReadByte(),
                                Change = br.ReadByte(),
                                Fastball = br.ReadByte(),
                                Forkball = br.ReadByte(),
                                Knuckler = br.ReadByte(),
                                Palmball = br.ReadByte(),
                                Screwball = br.ReadByte(),
                                Splitter = br.ReadByte(),
                                Sinker = br.ReadByte(),
                                Slider = br.ReadByte(),
                                Spitball = br.ReadByte(),
                                OutPitch = br.ReadByte(),
                                Style = br.ReadByte(),
                                Extra = br.ReadBytes(2),
                            });
                        }//while
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    System.Windows.MessageBox.Show("Error: " + e.ToString(), "Error");
                }

                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show("Error: " + ex.ToString(), "Error");
                }
            }
            readList = readList.Where(x => x.DebutYr != 0 && x.DebutYr != -1).ToList();//patch12
            return readList;
        }

        public IEnumerable<DMBLeague> League(string path)
        {
            var sendpath = path + "\\DMBLEAG.IDX";
            GETIDXONEA(sendpath);
            var Start = 1042;
            GETIDXONE(sendpath, Start);//datlist
            List<DMBLeague> readList = new List<DMBLeague>();
            path += "\\DMBLEAG.DAT";
            if (path != null && File.Exists(path))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        foreach (var i in datlist)
                        {
                            br.BaseStream.Position = i.A1;
                            var stop = br.BaseStream.Position;
                            while (br.BaseStream.Position == stop)//1076 
                            {
                                readList.Add(new DMBLeague
                                {
                                    ActFlag = br.ReadInt16(),
                                    Unk0 = br.ReadByte(),
                                    Unk0a = br.ReadByte(),
                                    LeagNo = br.ReadInt16(),
                                    Unk1 = br.ReadInt16(),
                                    Year = br.ReadInt16(),
                                    LeagNm = br.ReadBytes(32),
                                    DivName = br.ReadBytes(80),
                                    Unk2 = br.ReadInt16(),
                                    OrgID = br.ReadInt16(),
                                    Unk3 = br.ReadInt16(),
                                    DatFile = br.ReadByte(),
                                    T02 = br.ReadByte(),
                                    tmsd1 = br.ReadBytes(32),
                                    tmsd2 = br.ReadBytes(32),
                                    tmsd3 = br.ReadBytes(32),
                                    tmsd4 = br.ReadBytes(32),
                                    gms = br.ReadByte(),
                                    DH = br.ReadByte(),
                                    Injury = br.ReadByte(),
                                    SacFly = br.ReadByte(),
                                    WarmUp = br.ReadByte(),
                                    GameStats = br.ReadByte(),
                                    TrLi = br.ReadByte(),
                                    Weather = br.ReadByte(),
                                    PT = br.ReadByte(),
                                    Clutch = br.ReadByte(),
                                    Format = br.ReadByte(),
                                    Boxscores = br.ReadByte(),
                                    Scoresheets = br.ReadByte(),
                                    GameLogs = br.ReadByte(),
                                    GameAccounts = br.ReadByte(),
                                    A2a = br.ReadByte(),
                                    PTLimits = br.ReadByte(),
                                    TotalPA = br.ReadByte(),
                                    PASplits = br.ReadByte(),
                                    GS = br.ReadByte(),
                                    BF = br.ReadByte(),
                                    IP = br.ReadByte(),
                                    FieldG = br.ReadByte(),
                                    Post = br.ReadByte(),
                                    TotalPAPer = br.ReadInt16(),
                                    PASplitsPer = br.ReadInt16(),
                                    GSPer = br.ReadInt16(),
                                    BFPer = br.ReadInt16(),
                                    IPPer = br.ReadInt16(),
                                    FieldGPer = br.ReadInt16(),
                                    PostPer = br.ReadInt16(),
                                    A15 = br.ReadByte(),
                                    B1 = br.ReadByte(),
                                    LGMYear = br.ReadInt16(),
                                    LGMonth = br.ReadByte(),
                                    LGDay = br.ReadByte(),
                                    Unk5 = br.ReadByte(),
                                    Unk7 = br.ReadByte(),
                                    Unk8 = br.ReadByte(),
                                    Unk9 = br.ReadByte(),
                                    Unk10 = br.ReadByte(),
                                    Unk11 = br.ReadByte(),
                                    Unk12 = br.ReadByte(),
                                    WCCSFormat = br.ReadBytes(20),
                                    DCCSFormat = br.ReadBytes(20),
                                    LCCSFormat = br.ReadBytes(20),
                                    Unk6 = br.ReadByte(),
                                    LWC1T1 = br.ReadInt16(),
                                    LWC1T2 = br.ReadInt16(),
                                    LWC1T1Wins = br.ReadByte(),
                                    LWC1T2Wins = br.ReadByte(),
                                    LWC1Format = br.ReadByte(),
                                    LWC1SERA = br.ReadByte(),
                                    LWC2T1 = br.ReadInt16(),
                                    LWC2T2 = br.ReadInt16(),
                                    LWC2T1Wins = br.ReadByte(),
                                    LWC2T2Wins = br.ReadByte(),
                                    LWC2Format = br.ReadByte(),
                                    LWC2SERA = br.ReadByte(),
                                    LWC3T1 = br.ReadInt16(),
                                    LWC3T2 = br.ReadInt16(),
                                    LWC3T1Wins = br.ReadByte(),
                                    LWC3T2Wins = br.ReadByte(),
                                    LWC3Format = br.ReadByte(),
                                    LWC3SERA = br.ReadByte(),
                                    LWC4T1 = br.ReadInt16(),
                                    LWC4T2 = br.ReadInt16(),
                                    LWC4T1Wins = br.ReadByte(),
                                    LWC4T2Wins = br.ReadByte(),
                                    LWC4Format = br.ReadByte(),
                                    LWC4SERA = br.ReadByte(),
                                    LDC1T1 = br.ReadInt16(),
                                    LDC1T2 = br.ReadInt16(),
                                    LDC1T1Wins = br.ReadByte(),
                                    LDC1T2Wins = br.ReadByte(),
                                    LDC1Format = br.ReadByte(),
                                    LDC1SERA = br.ReadByte(),
                                    LDC2T1 = br.ReadInt16(),
                                    LDC2T2 = br.ReadInt16(),
                                    LDC2T1Wins = br.ReadByte(),
                                    LDC2T2Wins = br.ReadByte(),
                                    LDC2Format = br.ReadByte(),
                                    LDC2SERA = br.ReadByte(),
                                    LLC1T1 = br.ReadInt16(),
                                    LLC1T2 = br.ReadInt16(),
                                    LLC1T1Wins = br.ReadByte(),
                                    LLC1T2Wins = br.ReadByte(),
                                    LLC1Format = br.ReadByte(),
                                    LLC1SERA = br.ReadByte(),
                                    LLC1T11 = br.ReadByte(),
                                    LLC1T21 = br.ReadByte(),
                                    LLC1SER1 = br.ReadByte(),
                                    LLC1SER2 = br.ReadByte(),
                                    LLC1SER3 = br.ReadByte(),
                                    Unk4 = br.ReadBytes(645),
                                });
                            }
                        }
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            return readList;
        }

        public IEnumerable<DMBLeague> League12(string path)
        {
            var sendpath = path + "\\DMBLEAG.IDX";
            GETIDXONEA(sendpath);
            var Start = 1042;
            GETIDXONE(sendpath, Start);//datlist
            List<DMBLeague> readList = new List<DMBLeague>();
            path += "\\DMBLEAG.DAT";
            if (path != null && File.Exists(path))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        foreach (var i in datlist)
                        {
                            br.BaseStream.Position = i.A1;
                            var stop = br.BaseStream.Position;
                            while (br.BaseStream.Position == stop)//1076 
                            {
                                readList.Add(new DMBLeague
                                {
                                    ActFlag = br.ReadInt16(),
                                    Unk0 = br.ReadByte(),
                                    Unk0a = br.ReadByte(),
                                    LeagNo = br.ReadInt16(),
                                    Unk1 = br.ReadInt16(),
                                    Year = br.ReadInt16(),
                                    LeagNm = br.ReadBytes(32),
                                    DivName = br.ReadBytes(80),
                                    Unk2 = br.ReadInt16(),
                                    OrgID = br.ReadInt16(),
                                    Unk3 = br.ReadInt16(),
                                    DatFile = br.ReadByte(),
                                    T02 = br.ReadByte(),
                                    tmsd1 = br.ReadBytes(32),
                                    tmsd2 = br.ReadBytes(32),
                                    tmsd3 = br.ReadBytes(32),
                                    tmsd4 = br.ReadBytes(32),
                                    gms = br.ReadByte(),
                                    DH = br.ReadByte(),
                                    Injury = br.ReadByte(),
                                    SacFly = br.ReadByte(),
                                    WarmUp = br.ReadByte(),
                                    MPC = br.ReadByte(),
                                    IWR = br.ReadByte(),
                                    BPR = br.ReadByte(),
                                    EIRR = br.ReadByte(),
                                    EIRP = br.ReadByte(),
                                    UPC = br.ReadByte(),
                                    ILB = br.ReadByte(),
                                    ILP = br.ReadByte(),
                                    GameStats = br.ReadByte(),
                                    TrLi = br.ReadByte(),
                                    Weather = br.ReadByte(),
                                    PT = br.ReadByte(),
                                    Clutch = br.ReadByte(),
                                    Format = br.ReadByte(),
                                    Boxscores = br.ReadByte(),
                                    Scoresheets = br.ReadByte(),
                                    GameLogs = br.ReadByte(),
                                    GameAccounts = br.ReadByte(),
                                    A2a = br.ReadByte(),
                                    PTLimits = br.ReadByte(),
                                    TotalPA = br.ReadByte(),
                                    PASplits = br.ReadByte(),
                                    GS = br.ReadByte(),
                                    BF = br.ReadByte(),
                                    IP = br.ReadByte(),
                                    FieldG = br.ReadByte(),
                                    Post = br.ReadByte(),
                                    TotalPAPer = br.ReadInt16(),
                                    PASplitsPer = br.ReadInt16(),
                                    GSPer = br.ReadInt16(),
                                    BFPer = br.ReadInt16(),
                                    IPPer = br.ReadInt16(),
                                    FieldGPer = br.ReadInt16(),
                                    PostPer = br.ReadInt16(),
                                    A15 = br.ReadByte(),
                                    B1 = br.ReadByte(),
                                    LGMYear = br.ReadInt16(),
                                    LGMonth = br.ReadByte(),
                                    LGDay = br.ReadByte(),
                                    Unk5 = br.ReadByte(),
                                    Unk7 = br.ReadByte(),
                                    Unk8 = br.ReadByte(),
                                    Unk9 = br.ReadByte(),
                                    Unk10 = br.ReadByte(),
                                    Unk11 = br.ReadByte(),
                                    Unk12 = br.ReadByte(),
                                    WCCSFormat = br.ReadBytes(20),
                                    DCCSFormat = br.ReadBytes(20),
                                    LCCSFormat = br.ReadBytes(20),
                                    Unk6 = br.ReadByte(),
                                    LWC1T1 = br.ReadInt16(),
                                    LWC1T2 = br.ReadInt16(),
                                    LWC1T1Wins = br.ReadByte(),
                                    LWC1T2Wins = br.ReadByte(),
                                    LWC1Format = br.ReadByte(),
                                    LWC1SERA = br.ReadByte(),
                                    LWC2T1 = br.ReadInt16(),
                                    LWC2T2 = br.ReadInt16(),
                                    LWC2T1Wins = br.ReadByte(),
                                    LWC2T2Wins = br.ReadByte(),
                                    LWC2Format = br.ReadByte(),
                                    LWC2SERA = br.ReadByte(),
                                    LWC3T1 = br.ReadInt16(),
                                    LWC3T2 = br.ReadInt16(),
                                    LWC3T1Wins = br.ReadByte(),
                                    LWC3T2Wins = br.ReadByte(),
                                    LWC3Format = br.ReadByte(),
                                    LWC3SERA = br.ReadByte(),
                                    LWC4T1 = br.ReadInt16(),
                                    LWC4T2 = br.ReadInt16(),
                                    LWC4T1Wins = br.ReadByte(),
                                    LWC4T2Wins = br.ReadByte(),
                                    LWC4Format = br.ReadByte(),
                                    LWC4SERA = br.ReadByte(),
                                    LDC1T1 = br.ReadInt16(),
                                    LDC1T2 = br.ReadInt16(),
                                    LDC1T1Wins = br.ReadByte(),
                                    LDC1T2Wins = br.ReadByte(),
                                    LDC1Format = br.ReadByte(),
                                    LDC1SERA = br.ReadByte(),
                                    LDC2T1 = br.ReadInt16(),
                                    LDC2T2 = br.ReadInt16(),
                                    LDC2T1Wins = br.ReadByte(),
                                    LDC2T2Wins = br.ReadByte(),
                                    LDC2Format = br.ReadByte(),
                                    LDC2SERA = br.ReadByte(),
                                    LLC1T1 = br.ReadInt16(),
                                    LLC1T2 = br.ReadInt16(),
                                    LLC1T1Wins = br.ReadByte(),
                                    LLC1T2Wins = br.ReadByte(),
                                    LLC1Format = br.ReadByte(),
                                    LLC1SERA = br.ReadByte(),
                                    LLC1T11 = br.ReadByte(),
                                    LLC1T21 = br.ReadByte(),
                                    LLC1SER1 = br.ReadByte(),
                                    LLC1SER2 = br.ReadByte(),
                                    LLC1SER3 = br.ReadByte(),
                                    Unk4 = br.ReadBytes(645),
                                });
                            }
                        }
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            return readList;
        }

        public IEnumerable<DMBTeam> Team(string path)
        {
            var sendpath = path + "\\DMBTEAM.IDX";
            GETIDXONEA(sendpath);//sets the record count
            var Start = 1042;
            GETIDXONE(sendpath, Start);//count and position
            List<DMBTeam> readList = new List<DMBTeam>();
            readList.Clear();

            var bpath = path + "\\DMBTEAM.DAT";
            if (bpath != null && File.Exists(bpath))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(bpath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        foreach (var i in datlist)
                        {
                            br.BaseStream.Position = i.A1;
                            var stop = br.BaseStream.Position;
                            while (br.BaseStream.Position == stop)
                            {
                                readList.Add(new DMBTeam
                                {
                                    ActFlag = br.ReadInt16(),
                                    ALLCC = br.ReadBytes(2),
                                    TeamNo = br.ReadInt16(),
                                    tmUID = br.ReadInt16(),
                                    TeamYr = br.ReadInt16(),
                                    League = br.ReadInt16(),
                                    Allalike = br.ReadInt16(),
                                    Park = br.ReadInt16(),
                                    Unk2 = br.ReadByte(),
                                    city = br.ReadBytes(16),
                                    nick = br.ReadBytes(16),
                                    Unk3 = br.ReadBytes(44),
                                    abbr = br.ReadBytes(4),
                                    Unk4 = br.ReadBytes(4),
                                    Unk5 = br.ReadByte(),
                                    lids = br.ReadBytes(160),
                                    Unk6a = br.ReadBytes(2),
                                    uids = br.ReadBytes(320),//possible 80 man roster
                                    StatusRoster = br.ReadBytes(80),
                                    OpeningDayRoster = br.ReadBytes(80),
                                    lob = br.ReadInt16(),
                                    dp = br.ReadInt16(),
                                    unk7 = br.ReadInt16(),
                                    rsc = br.ReadInt16(),
                                    ral = br.ReadInt16(),
                                    won = br.ReadByte(),
                                    lost = br.ReadByte(),
                                    tied = br.ReadByte(),
                                    Unk8 = br.ReadByte(),
                                    sho = br.ReadByte(),
                                    SimStat1 = br.ReadBytes(16),
                                    SimStat2 = br.ReadByte(),
                                    rsSimLOB = br.ReadInt16(),
                                    rsSimDP = br.ReadInt16(),
                                    rsSimTies1 = br.ReadByte(),
                                    rsSimTies2 = br.ReadByte(),
                                    rsSimRS = br.ReadInt16(),
                                    rsSimRA = br.ReadInt16(),
                                    rsSimWin = br.ReadByte(),
                                    rsSimLoss = br.ReadByte(),
                                    unkn = br.ReadByte(),
                                    unkn2 = br.ReadByte(),
                                    rsSimSHO = br.ReadByte(),
                                    SimStat3 = br.ReadBytes(16),
                                    SimStat4 = br.ReadBytes(16),
                                    SimStat5 = br.ReadBytes(16),
                                    SimStat6 = br.ReadBytes(16),
                                    unkn1 = br.ReadByte(),
                                    lastgmyr = br.ReadInt16(),////////////////////
                                    lastgmmo = br.ReadByte(),
                                    lastgmda = br.ReadByte(),
                                    lasthmgmyr = br.ReadInt16(),/////////////////
                                    lasthmgmmo = br.ReadByte(),
                                    lasthmgmda = br.ReadByte(),
                                    Unk10 = br.ReadInt16(),
                                    mgrfname = br.ReadBytes(14),
                                    mgrlname = br.ReadBytes(16),
                                    mgrnname = br.ReadBytes(32),
                                });
                            }
                        }
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }

            foreach (var i in readList)
            {
                var roster = new List<string>();
                for (var n = 0; n < i.uids.Length; n += 2)
                {
                    var sample = BitConverter.ToInt16(i.uids, n);

                    if (sample != 0 && sample != -1 && Convert.ToInt32(sample) > 9999)// valid uid from the data, skips blank lines
                    {
                        roster.Add(sample.ToString());
                    }
                }
                i.UIDList = roster;
            }
            foreach (var i in readList)
            {
                var roster = new List<string>();
                for (var n = 0; n < i.lids.Length; n += 2)
                {
                    var sample = BitConverter.ToInt16(i.lids, n);

                    if (sample != -1)// valid uid from the data, skips blank lines
                    {
                        roster.Add(sample.ToString());
                    }
                }
                i.PIDList = roster;
            }

            return readList;
        }

        public IEnumerable<DMBStat> DMBGS(string path)  //Verified
        {
            List<DMBStat> readList = new List<DMBStat>();
            var sendpath = path + "\\DMBGS.IDX";
            GETIDX(sendpath);
            path += "\\DMBGS.DAT";
            if (path != null && File.Exists(path))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        br.BaseStream.Position = 2790;
                        var Iter = RC * 310 + 2790;
                        while (br.BaseStream.Position < Iter)//310 bytes
                        {
                            readList.Add(new DMBStat
                            {
                                ActiveFlag = br.ReadInt16(),
                                gstatsID = br.ReadInt16(),
                                StatType = br.ReadInt16(),
                                playerteamID = br.ReadInt16(),
                                TeamNo = br.ReadInt16(),
                                x1 = br.ReadInt16(),
                                x2 = br.ReadInt16(),
                                schgm1yr = br.ReadInt16(),
                                schgm1mo = br.ReadByte(),
                                schgm1da = br.ReadByte(),
                                schgmxyr = br.ReadInt16(),
                                schgmxmo = br.ReadByte(),
                                schgmxda = br.ReadByte(),
                                hatbats = br.ReadInt16(),
                                hruns = br.ReadInt16(),
                                hrbi = br.ReadInt16(),
                                hhits = br.ReadInt16(),
                                h2b = br.ReadByte(),
                                h3b = br.ReadByte(),
                                hhr = br.ReadByte(),
                                hhbp = br.ReadByte(),
                                hso = br.ReadInt16(),
                                hw = br.ReadInt16(),
                                hiw = br.ReadByte(),
                                hsb = br.ReadByte(),
                                hcs = br.ReadByte(),
                                hgw = br.ReadByte(),
                                hsh = br.ReadByte(),
                                hsf = br.ReadByte(),
                                hgdp = br.ReadByte(),
                                hgp = br.ReadByte(),
                                hgs = br.ReadByte(),
                                hci = br.ReadByte(),
                                hlab = br.ReadInt16(),
                                hlh = br.ReadInt16(),
                                hl2b = br.ReadByte(),
                                hl3b = br.ReadByte(),
                                hlhr = br.ReadByte(),
                                hlrbi = br.ReadByte(),
                                hlhbp = br.ReadByte(),
                                hlbb = br.ReadByte(),
                                hlk = br.ReadInt16(),
                                hlsh = br.ReadByte(), //61
                                hlci = br.ReadByte(),
                                hlsf = br.ReadByte(),
                                hliw = br.ReadByte(),
                                hlgdp = br.ReadByte(),
                                hunk96 = br.ReadByte(),
                                hrab = br.ReadInt16(),
                                hrh = br.ReadInt16(),
                                hr2b = br.ReadByte(),
                                hr3b = br.ReadByte(),
                                hrhr = br.ReadByte(),
                                hrrbi = br.ReadByte(),
                                hrhbp = br.ReadByte(),
                                hrbb = br.ReadByte(),
                                hrk = br.ReadInt16(),//78
                                hrsh = br.ReadByte(),
                                hrci = br.ReadByte(),
                                hrsf = br.ReadByte(),
                                hriw = br.ReadByte(),
                                hrgdp = br.ReadByte(),
                                hunk97 = br.ReadByte(),
                                chs = br.ReadByte(),
                                lhs = br.ReadByte(),
                                pbfp = br.ReadInt16(), //88
                                pouts = br.ReadInt16(),
                                patbats = br.ReadInt16(),
                                phits = br.ReadInt16(),
                                pso = br.ReadInt16(),
                                pw = br.ReadInt16(),
                                piw = br.ReadByte(),
                                phbp = br.ReadByte(),
                                pruns = br.ReadInt16(),
                                peruns = br.ReadInt16(),//104
                                pdb = br.ReadByte(),
                                ptp = br.ReadByte(),
                                PHR = br.ReadByte(),
                                pwp = br.ReadByte(),
                                pbk = br.ReadByte(),
                                psh = br.ReadByte(),
                                psf = br.ReadByte(),
                                pci = br.ReadByte(),
                                pgdp = br.ReadByte(),
                                pwon = br.ReadByte(),
                                plost = br.ReadByte(),
                                psave = br.ReadByte(),
                                psop = br.ReadByte(),
                                pbs = br.ReadByte(),
                                phold = br.ReadByte(),
                                pqs = br.ReadByte(),//120
                                prs = br.ReadByte(),
                                pxl = br.ReadByte(),
                                pir = br.ReadByte(),
                                pirs = br.ReadByte(),
                                prl = br.ReadByte(),
                                prls = br.ReadByte(),
                                psho = br.ReadByte(),
                                pcg = br.ReadByte(),
                                pgp = br.ReadByte(),
                                pgf = br.ReadByte(),
                                pgs = br.ReadByte(),
                                psb = br.ReadByte(),
                                pcs = br.ReadByte(),
                                ppk = br.ReadByte(),
                                pvlab = br.ReadInt16(),
                                pvlh = br.ReadInt16(),//138
                                pvl2b = br.ReadByte(),
                                pvl3b = br.ReadByte(),
                                pvlhr = br.ReadByte(),
                                pvlrbi = br.ReadByte(),
                                pvlhbp = br.ReadByte(),
                                pvlbb = br.ReadByte(),
                                pvlso = br.ReadInt16(),
                                pvlsh = br.ReadByte(),
                                pvlci = br.ReadByte(),
                                pvlsf = br.ReadByte(),
                                pvliw = br.ReadByte(),
                                pvgdp = br.ReadInt16(),//52
                                pvrab = br.ReadInt16(),
                                pvrh = br.ReadInt16(),
                                pvr2b = br.ReadByte(),
                                pvr3b = br.ReadByte(),
                                pvrhr = br.ReadByte(),
                                pvrrbi = br.ReadByte(),
                                pvrhbp = br.ReadByte(),
                                pvrbb = br.ReadByte(),
                                pvrso = br.ReadInt16(),//164
                                pvrsh = br.ReadByte(),
                                pvrci = br.ReadByte(),
                                pvrsf = br.ReadByte(),
                                pvriw = br.ReadByte(),//////////////////////////////////////////////////////////
                                pvrgdp = br.ReadInt16(),//170
                                ppkoff = br.ReadInt16(),
                                pphb = br.ReadInt16(),
                                ppib = br.ReadInt16(),
                                ppballs = br.ReadInt16(),
                                ppcs = br.ReadInt16(),
                                ppss = br.ReadInt16(),
                                ppfb = br.ReadInt16(),
                                ppip = br.ReadInt16(),
                                fpo1 = br.ReadInt16(),//187 - 204    18bytes
                                fpo2 = br.ReadInt16(),
                                fpo3 = br.ReadInt16(),
                                fpo4 = br.ReadInt16(),
                                fpo5 = br.ReadInt16(),
                                fpo6 = br.ReadInt16(),
                                fpo7 = br.ReadInt16(),
                                fpo8 = br.ReadInt16(),
                                fpo9 = br.ReadInt16(),
                                fa1 = br.ReadInt16(),//205-222
                                fa2 = br.ReadInt16(),
                                fa3 = br.ReadInt16(),
                                fa4 = br.ReadInt16(),
                                fa5 = br.ReadInt16(),
                                fa6 = br.ReadInt16(),
                                fa7 = br.ReadInt16(),
                                fa8 = br.ReadInt16(),
                                fa9 = br.ReadInt16(),
                                fe1 = br.ReadByte(),//223-231
                                fe2 = br.ReadByte(),
                                fe3 = br.ReadByte(),
                                fe4 = br.ReadByte(),
                                fe5 = br.ReadByte(),
                                fe6 = br.ReadByte(),
                                fe7 = br.ReadByte(),
                                fe8 = br.ReadByte(),
                                fe9 = br.ReadByte(),
                                fg1 = br.ReadByte(),//232-240
                                fg2 = br.ReadByte(),
                                fg3 = br.ReadByte(),
                                fg4 = br.ReadByte(),
                                fg5 = br.ReadByte(),
                                fg6 = br.ReadByte(),
                                fg7 = br.ReadByte(),
                                fg8 = br.ReadByte(),
                                fg9 = br.ReadByte(),
                                fouts1 = br.ReadInt16(),//241-258
                                fouts2 = br.ReadInt16(),
                                fouts3 = br.ReadInt16(),
                                fouts4 = br.ReadInt16(),
                                fouts5 = br.ReadInt16(),
                                fouts6 = br.ReadInt16(),
                                fouts7 = br.ReadInt16(),
                                fouts8 = br.ReadInt16(),
                                fouts9 = br.ReadInt16(),
                                fdp1 = br.ReadInt16(),//259-276
                                fdp2 = br.ReadInt16(),
                                fdp3 = br.ReadInt16(),
                                fdp4 = br.ReadInt16(),
                                fdp5 = br.ReadInt16(),
                                fdp6 = br.ReadInt16(),
                                fdp7 = br.ReadInt16(),
                                fdp8 = br.ReadInt16(),
                                fdp9 = br.ReadInt16(),
                                fgs1 = br.ReadByte(),//277-285
                                fgs2 = br.ReadByte(),
                                fgs3 = br.ReadByte(),
                                fgs4 = br.ReadByte(),
                                fgs5 = br.ReadByte(),
                                fgs6 = br.ReadByte(),
                                fgs7 = br.ReadByte(),
                                fgs8 = br.ReadByte(),
                                fgs9 = br.ReadByte(),
                                fcpb = br.ReadByte(),
                                fcsb = br.ReadByte(),
                                fccs = br.ReadByte(),
                                fcpk = br.ReadByte(),
                                unk99 = br.ReadByte(),
                                gsvlh1 = br.ReadByte(),
                                gsvlh2 = br.ReadByte(),
                                gsvlh3 = br.ReadByte(),
                                gsvlh4 = br.ReadByte(),
                                gsvlh5 = br.ReadByte(),
                                gsvlh6 = br.ReadByte(),
                                gsvlh7 = br.ReadByte(),
                                gsvlh8 = br.ReadByte(),
                                gsvlh9 = br.ReadByte(),
                                gsvrh1 = br.ReadByte(),
                                gsvrh2 = br.ReadByte(),
                                gsvrh3 = br.ReadByte(),
                                gsvrh4 = br.ReadByte(),
                                gsvrh5 = br.ReadByte(),
                                gsvrh6 = br.ReadByte(),
                                gsvrh7 = br.ReadByte(),
                                gsvrh8 = br.ReadByte(),
                                gsvrh9 = br.ReadByte(),
                                gactive = br.ReadInt16(),
                            });
                        }
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            readList = readList.Where(x => x.ActiveFlag == 0).ToList();
            return readList;
        }

        public IEnumerable<DMBplyr> DMBPlayer(string path) //Verified
        {
            List<DMBplyr> readList = new List<DMBplyr>();
            var sendpath = path + "\\DMBPLYR.IDX";
            GETIDX(sendpath);
            path += "\\DMBPLYR.DAT";
            if (path != null && File.Exists(path))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        br.BaseStream.Position = 3984;
                        while (br.BaseStream.Position < br.BaseStream.Length - 664) // 664 bytes
                        {
                            readList.Add(new DMBplyr
                            {
                                actflag = br.ReadInt16(),
                                all118 = br.ReadInt16(),
                                playerteamID = br.ReadInt16(),
                                all18 = br.ReadInt16(),
                                playerUID = br.ReadInt32(),
                                year = br.ReadInt16(),
                                gstatsID = br.ReadInt16(),
                                tmseq = br.ReadInt16(),
                                allFF = br.ReadInt16(),
                                imgtype = br.ReadByte(),
                                ppos = br.ReadByte(),
                                fname = br.ReadBytes(14),
                                lname = br.ReadBytes(16),
                                sname = br.ReadBytes(16),
                                nname = br.ReadBytes(32),
                                byr = br.ReadInt16(),
                                bmo = br.ReadByte(),
                                bda = br.ReadByte(),
                                salary = br.ReadInt32(),
                                Contract_end = br.ReadInt16(),
                                Type = br.ReadByte(),
                                bats = br.ReadByte(),
                                throws = br.ReadByte(),
                                x71 = br.ReadByte(),
                                x72 = br.ReadByte(),
                                x73 = br.ReadByte(),
                                injury = br.ReadByte(),//3 0 = Iron 1 = Normal   2 = Prone 3 = Very Prone
                                rstrpcta = br.ReadByte(),//games on active roster %
                                rstrpctd = br.ReadByte(),//games on DL or Injured %
                                x9 = br.ReadByte(),
                                x9a = br.ReadBytes(6),//43
                                be3bvla = br.ReadByte(),
                                behrvl = br.ReadByte(),
                                behrvla = br.ReadByte(),
                                behbvl = br.ReadByte(),
                                behbvla = br.ReadByte(),
                                bebbvl = br.ReadByte(),
                                bebbvla = br.ReadByte(),
                                besovl = br.ReadByte(),
                                besovla = br.ReadByte(),
                                beaovl = br.ReadByte(),
                                beaovla = br.ReadByte(),
                                bedpvl = br.ReadByte(),
                                bedpvla = br.ReadByte(),
                                begovl = br.ReadByte(),
                                begovla = br.ReadByte(),
                                be1bvr = br.ReadByte(),
                                be1bvra = br.ReadByte(),
                                be2bvr = br.ReadByte(),
                                be2bvra = br.ReadByte(),
                                be3bvr = br.ReadByte(),
                                be3bvra = br.ReadByte(),
                                behrvr = br.ReadByte(),
                                behrvra = br.ReadByte(),
                                behbvr = br.ReadByte(),
                                behbvra = br.ReadByte(),
                                bebbvr = br.ReadByte(),
                                bebbvra = br.ReadByte(),
                                besovr = br.ReadByte(),
                                besovra = br.ReadByte(),
                                beaovr = br.ReadByte(),
                                beaovra = br.ReadByte(),
                                bedpvr = br.ReadByte(),
                                bedpvra = br.ReadByte(),
                                begovr = br.ReadByte(),
                                begovra = br.ReadByte(),
                                behpvl = br.ReadByte(),
                                behpvla = br.ReadByte(),
                                bestvl = br.ReadByte(),
                                bestvla = br.ReadByte(),
                                beswvl = br.ReadByte(),
                                beswvla = br.ReadByte(),
                                beflvl = br.ReadByte(),
                                beflvla = br.ReadByte(),
                                beinvl = br.ReadByte(),
                                beinvla = br.ReadByte(),
                                behpvr = br.ReadByte(),
                                behpvra = br.ReadByte(),
                                bestvr = br.ReadByte(),
                                bestvra = br.ReadByte(),
                                beswvr = br.ReadByte(),
                                beswvra = br.ReadByte(),
                                beflvr = br.ReadByte(),
                                beflvra = br.ReadByte(),
                                beinvr = br.ReadByte(),
                                beinvra = br.ReadByte(),
                                bbbbb = br.ReadByte(),
                                bbbbba = br.ReadByte(),
                                bclutch = br.ReadByte(),
                                bpwrvl = br.ReadByte(),
                                bpwrvr = br.ReadByte(),
                                bhittype = br.ReadByte(),
                                bbntsac = br.ReadByte(),
                                bbnthit = br.ReadByte(),
                                brun = br.ReadByte(),
                                bsteal = br.ReadByte(),
                                bjump = br.ReadByte(),
                                A1 = br.ReadByte(),
                                A2 = br.ReadByte(),
                                A3 = br.ReadByte(),
                                A4 = br.ReadByte(),
                                A5 = br.ReadByte(),
                                A6 = br.ReadByte(),
                                A7 = br.ReadByte(),
                                A8 = br.ReadByte(),
                                A9 = br.ReadByte(),
                                A10 = br.ReadByte(),
                                B1 = br.ReadByte(),
                                B2 = br.ReadByte(),
                                B3 = br.ReadByte(),
                                B4 = br.ReadByte(),
                                B5 = br.ReadByte(),
                                B6 = br.ReadByte(),
                                B7 = br.ReadByte(),
                                B8 = br.ReadByte(),
                                B9 = br.ReadByte(),
                                B10 = br.ReadByte(),
                                C1 = br.ReadByte(),
                                C2 = br.ReadByte(),
                                C3 = br.ReadByte(),
                                C4 = br.ReadByte(),
                                C5 = br.ReadByte(),
                                C6 = br.ReadByte(),
                                C7 = br.ReadByte(),
                                C8 = br.ReadByte(),
                                C9 = br.ReadByte(),
                                C10 = br.ReadByte(),
                                D1 = br.ReadByte(),
                                D2 = br.ReadByte(),
                                D3 = br.ReadByte(),
                                D4 = br.ReadByte(),
                                D5 = br.ReadByte(),
                                D6 = br.ReadByte(),
                                D7 = br.ReadByte(),
                                D8 = br.ReadByte(),
                                D9 = br.ReadByte(),
                                D10 = br.ReadByte(),
                                E1 = br.ReadByte(),
                                E2 = br.ReadByte(),
                                E3 = br.ReadByte(),
                                E4 = br.ReadByte(),
                                bcccc = br.ReadBytes(27),
                                pehrvr = br.ReadByte(),
                                pehrvra = br.ReadInt16(),
                                //pehbvr = br.ReadByte(),
                                pehbvra = br.ReadInt16(),
                                //pebbvr = br.ReadByte(),
                                pebbvra = br.ReadInt16(),
                                //pesovr = br.ReadByte(),
                                pesovra = br.ReadInt16(),
                                //peaovr = br.ReadByte(),
                                peaovra = br.ReadInt16(),
                                //pedpvr = br.ReadByte(),
                                pedpvra = br.ReadInt16(),
                                //pegovr = br.ReadByte(),
                                pegovra = br.ReadInt16(),
                                //pehpvl = br.ReadByte(),
                                pehpvla = br.ReadInt16(),
                                //pestvl = br.ReadByte(),
                                pestvla = br.ReadInt16(),
                                //peswvl = br.ReadByte(),
                                peswvla = br.ReadInt16(),
                                //peflvl = br.ReadByte(),
                                peflvla = br.ReadInt16(),
                                //peinvl = br.ReadByte(),
                                peinvla = br.ReadInt16(),
                                //pehpvr = br.ReadByte(),
                                pehpvra = br.ReadInt16(),
                                //pestvr = br.ReadByte(),
                                pestvra = br.ReadByte(),
                                peswvr = br.ReadByte(),
                                peswvra = br.ReadByte(),
                                peflvr = br.ReadByte(),
                                peflvra = br.ReadByte(),
                                peinvr = br.ReadByte(),
                                peinvra = br.ReadByte(),
                                pdddd = br.ReadByte(),
                                pdddda = br.ReadByte(),
                                sdur = br.ReadByte(),
                                rdur = br.ReadByte(),
                                rwp = br.ReadByte(),
                                rhld = br.ReadByte(),
                                rjam = br.ReadByte(),
                                rgbpct = br.ReadByte(),
                                rbalk = br.ReadByte(),
                                rbalka = br.ReadByte(),
                                parmangle = br.ReadByte(),
                                pvelocity = br.ReadByte(),
                                poutpitch = br.ReadByte(),
                                pstyle = br.ReadByte(),
                                pchg = br.ReadByte(),
                                pcrv = br.ReadByte(),
                                pcutf = br.ReadByte(),
                                pfast = br.ReadByte(),
                                pfork = br.ReadByte(),
                                pknklr = br.ReadByte(),
                                ppalm = br.ReadByte(),
                                pscrw = br.ReadByte(),
                                psnkr = br.ReadByte(),
                                psldr = br.ReadByte(),
                                pspit = br.ReadByte(),
                                psplit = br.ReadByte(),
                                rp = br.ReadByte(),
                                rc = br.ReadByte(),
                                r1b = br.ReadByte(),
                                r2b = br.ReadByte(),
                                r3b = br.ReadByte(),
                                rss = br.ReadByte(),
                                rlf = br.ReadByte(),
                                rcf = br.ReadByte(),
                                rrf = br.ReadByte(),
                                rx1 = br.ReadByte(),
                                perr = br.ReadByte(),
                                perra = br.ReadByte(),
                                cerr = br.ReadByte(),
                                cerra = br.ReadByte(),
                                p1berr = br.ReadByte(),
                                p1berra = br.ReadByte(),
                                p2berr = br.ReadByte(),
                                p2berra = br.ReadByte(),
                                p3berr = br.ReadByte(),
                                p3berra = br.ReadByte(),
                                sserr = br.ReadByte(),
                                sserra = br.ReadByte(),
                                lferr = br.ReadByte(),
                                lferra = br.ReadByte(),
                                cferr = br.ReadByte(),
                                cferra = br.ReadByte(),
                                rferr = br.ReadByte(),
                                rferra = br.ReadByte(),
                                thof = br.ReadByte(),
                                thc = br.ReadByte(),
                                cpb = br.ReadByte(),
                                cxx = br.ReadByte(),
                                hab = br.ReadInt16(),
                                hrun = br.ReadInt16(),
                                hrbi = br.ReadInt16(),
                                hhit = br.ReadInt16(),
                                h2b = br.ReadByte(),
                                frp = br.ReadByte(),//1 = ex, 2 = vg, 3 = av, 4 = fr, 5 = pr Fielding Range
                                frc = br.ReadByte(),
                                fr1b = br.ReadByte(),
                                fr2b = br.ReadByte(),////////////////////////////////////
                                fr3b = br.ReadByte(),
                                frss = br.ReadByte(),
                                frlf = br.ReadByte(),
                                frcf = br.ReadByte(),//////////////////////////////////////
                                frrf = br.ReadByte(),
                                hw3 = br.ReadByte(),
                                fep = br.ReadInt16(),// Fielding Error
                                fec = br.ReadInt16(),
                                fe1b = br.ReadInt16(),
                                fe2b = br.ReadInt16(),
                                fe3b = br.ReadInt16(),
                                fess = br.ReadInt16(),
                                felf = br.ReadInt16(),
                                fecf = br.ReadInt16(),
                                ferf = br.ReadInt16(),
                                hlhrbi = br.ReadByte(),
                                hlhhbp = br.ReadByte(),
                                hlhw = br.ReadByte(),
                                hlhso = br.ReadByte(),
                                bsatbats = br.ReadInt16(),
                                bsruns = br.ReadInt16(),
                                bsrbi = br.ReadInt16(),
                                bshits = br.ReadInt16(),
                                bs2b = br.ReadByte(),
                                bs3b = br.ReadByte(),
                                bshr = br.ReadByte(),
                                bshbp = br.ReadByte(),
                                bsso = br.ReadInt16(),
                                bsbb = br.ReadInt16(),
                                bsiw = br.ReadByte(),
                                bssb = br.ReadByte(),
                                bscs = br.ReadByte(),
                                bsgwrbi = br.ReadByte(),
                                bssacbunts = br.ReadByte(),
                                bssacflies = br.ReadByte(),
                                bsgidp = br.ReadByte(),
                                bsgames = br.ReadByte(),
                                bsgs = br.ReadByte(),
                                bsci = br.ReadByte(),
                                bvlab = br.ReadInt16(),
                                bvlhits = br.ReadInt16(),
                                bvl2b = br.ReadByte(),
                                bvl3b = br.ReadByte(),
                                bvlhr = br.ReadByte(),
                                bvlrbi = br.ReadByte(),
                                bvliw = br.ReadByte(),
                                bvlbb = br.ReadByte(),
                                bvlso = br.ReadInt16(),
                                bvlsh = br.ReadByte(),
                                bvlhbp = br.ReadByte(),
                                bvlsf = br.ReadByte(),
                                pbb = br.ReadByte(),
                                pbba = br.ReadByte(),
                                piw = br.ReadByte(),
                                bvrab = br.ReadInt16(),
                                bvrhits = br.ReadInt16(),
                                bvr2b = br.ReadByte(),
                                bvr3b = br.ReadByte(),
                                bvrhr = br.ReadByte(),
                                bvrrbi = br.ReadByte(),
                                bvriw = br.ReadByte(),
                                bvrbb = br.ReadByte(),
                                bvrso = br.ReadByte(),
                                bvrsf = br.ReadByte(),
                                bvrsh = br.ReadByte(),
                                pgdp = br.ReadByte(),
                                pw = br.ReadByte(),
                                pl = br.ReadByte(),
                                ps = br.ReadByte(),
                                psvopp = br.ReadByte(),
                                pbfaced = br.ReadInt16(),
                                pinnouts = br.ReadInt16(),
                                pbab = br.ReadInt16(),
                                pbhits = br.ReadInt16(),
                                pbso = br.ReadInt16(),
                                pbbb = br.ReadInt16(),
                                pibb = br.ReadByte(),
                                phbp = br.ReadByte(),
                                pbrun = br.ReadInt16(),
                                pberun = br.ReadInt16(),
                                pb2b = br.ReadByte(),
                                pb3b = br.ReadByte(),
                                pbhr = br.ReadByte(),
                                pwp = br.ReadByte(),
                                pbalks = br.ReadByte(),
                                pbsh = br.ReadByte(),
                                pbsf = br.ReadByte(),
                                plhhbp = br.ReadByte(),
                                pbgdp = br.ReadByte(),
                                pbwin = br.ReadByte(),
                                ploss = br.ReadByte(),
                                prsave = br.ReadByte(),
                                prsaveopp = br.ReadByte(),
                                prbs = br.ReadByte(),
                                prhold = br.ReadByte(),
                                psqstart = br.ReadByte(),
                                psrs = br.ReadInt16(),
                                prir = br.ReadByte(),
                                prirs = br.ReadByte(),
                                psrl = br.ReadByte(),
                                psrls = br.ReadByte(),
                                pssho = br.ReadByte(),
                                pscg = br.ReadByte(),
                                pgames = br.ReadByte(),
                                pgf = br.ReadByte(),
                                psgs = br.ReadByte(),
                                psstolenbase = br.ReadByte(),
                                pscaughtstealing = br.ReadByte(),
                                pspo = br.ReadByte(),
                                pvlab = br.ReadInt16(),
                                pvlhits = br.ReadInt16(),
                                pvl2b = br.ReadByte(),
                                pvl3b = br.ReadByte(),
                                pvlhr = br.ReadByte(),
                                pvlrbi = br.ReadByte(),
                                pvlhbp = br.ReadByte(),
                                pvlbb = br.ReadByte(),
                                pvlso = br.ReadInt16(),
                                pvlsh = br.ReadByte(),
                                pvliw = br.ReadByte(),
                                pvlsf = br.ReadByte(),
                                fout = br.ReadByte(),
                                fouta = br.ReadByte(),
                                fdp = br.ReadByte(),
                                pvrab = br.ReadInt16(),
                                pvrhits = br.ReadInt16(),
                                pvr2b = br.ReadByte(),
                                pvr3b = br.ReadByte(),
                                pvrhr = br.ReadByte(),
                                pvrrbi = br.ReadByte(),
                                pvrhbp = br.ReadByte(),
                                pvrbb = br.ReadByte(),
                                pvrso = br.ReadInt16(),
                                pvrsh = br.ReadByte(),
                                unk1 = br.ReadByte(),
                                pvrsf = br.ReadByte(),
                                pvriw = br.ReadByte(),
                                x1 = br.ReadByte(),
                                x2 = br.ReadByte(),
                                fpo1 = br.ReadInt16(),
                                fpo2 = br.ReadInt16(),
                                fpo3 = br.ReadInt16(),
                                fpo4 = br.ReadInt16(),
                                fpo5 = br.ReadInt16(),
                                fpo6 = br.ReadInt16(),
                                fpo7 = br.ReadInt16(),
                                fpo8 = br.ReadInt16(),
                                fpo9 = br.ReadInt16(),
                                fa1 = br.ReadInt16(),
                                fa2 = br.ReadInt16(),
                                fa3 = br.ReadInt16(),
                                fa4 = br.ReadInt16(),
                                fa5 = br.ReadInt16(),
                                fa6 = br.ReadInt16(),
                                fa7 = br.ReadInt16(),
                                fa8 = br.ReadInt16(),
                                fa9 = br.ReadInt16(),
                                fe1 = br.ReadByte(),
                                fe2 = br.ReadByte(),
                                fe3 = br.ReadByte(),
                                fe4 = br.ReadByte(),
                                fe5 = br.ReadByte(),
                                fe6 = br.ReadByte(),
                                fe7 = br.ReadByte(),
                                fe8 = br.ReadByte(),
                                fe9 = br.ReadByte(),
                                fg1 = br.ReadByte(),
                                fg2 = br.ReadByte(),
                                fg3 = br.ReadByte(),
                                fg4 = br.ReadByte(),
                                fg5 = br.ReadByte(),
                                fg6 = br.ReadByte(),
                                fg7 = br.ReadByte(),
                                fg8 = br.ReadByte(),
                                fg9 = br.ReadByte(),
                                fouts1 = br.ReadInt16(),
                                fouts2 = br.ReadInt16(),
                                fouts3 = br.ReadInt16(),
                                fouts4 = br.ReadInt16(),
                                fouts5 = br.ReadInt16(),
                                fouts6 = br.ReadInt16(),
                                fouts7 = br.ReadInt16(),
                                fouts8 = br.ReadInt16(),
                                fouts9 = br.ReadInt16(),
                                fdp1 = br.ReadInt16(),
                                fdp2 = br.ReadInt16(),
                                fdp3 = br.ReadInt16(),
                                fdp4 = br.ReadInt16(),
                                fdp5 = br.ReadInt16(),
                                fdp6 = br.ReadInt16(),
                                fdp7 = br.ReadInt16(),
                                fdp8 = br.ReadInt16(),
                                fdp9 = br.ReadInt16(),
                                fgs1 = br.ReadByte(),//P
                                fgs2 = br.ReadByte(),//C
                                fgs3 = br.ReadByte(),//1B
                                fgs4 = br.ReadByte(),//2B
                                fgs5 = br.ReadByte(),//3B
                                fgs6 = br.ReadByte(),//SS
                                fgs7 = br.ReadByte(),//LF
                                fgs8 = br.ReadByte(),//CF
                                fgs9 = br.ReadByte(),//RF
                                spacer = br.ReadBytes(4),
                                Unk = br.ReadByte(),
                                gsvl2 = br.ReadByte(),//c
                                gsvl3 = br.ReadByte(),//1b
                                gsvl4 = br.ReadByte(),//2b
                                gsvl5 = br.ReadByte(),//3b
                                gsvl6 = br.ReadByte(),//ss
                                gsvl7 = br.ReadByte(),//lf
                                gsvl8 = br.ReadByte(),//cf
                                gsvl9 = br.ReadByte(),//rf
                                gsvldh = br.ReadByte(),//dh
                                gsvr2 = br.ReadByte(),
                                gsvr3 = br.ReadByte(),
                                gsvr4 = br.ReadByte(),
                                gsvr5 = br.ReadByte(),
                                gsvr6 = br.ReadByte(),
                                gsvr7 = br.ReadByte(),
                                gsvr8 = br.ReadByte(),
                                gsvr9 = br.ReadByte(),
                                gsvrdh = br.ReadByte(),
                            });
                        }
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            readList = readList.Where(x => x.gstatsID != -1).ToList();
            readList = readList.Where(x => x.actflag == 0).ToList();
            return readList;
        }

        public IEnumerable<Park> GetParks(string path)//Park 154 bytes
        {
            var sendpath = path + "\\DMBPARK.IDX";
            GETIDXONEA(sendpath);
            List<Park> readList = new List<Park>();
            path += "\\DMBPARK.DAT";
            if (path != null && File.Exists(path))
            {
                try
                {
                    RC++;
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        br.BaseStream.Position = Ind + 2;//2466
                        var stop = (RC * 154) + Ind;
                        while (br.BaseStream.Position < br.BaseStream.Length - 154)
                        {
                            readList.Add(new Park
                            {
                                ID = br.ReadInt16(),
                                UID = br.ReadInt16(),
                                Year = br.ReadInt16(),
                                nParkN = br.ReadBytes(30),//38
                                nCity = br.ReadBytes(16),//70
                                nFilena = br.ReadBytes(31),
                                U1 = br.ReadBytes(1),
                                nCover = br.ReadByte(),
                                nSurface = br.ReadByte(),
                                nFoul = br.ReadByte(),
                                nTZ = br.ReadByte(),
                                nAvgWndVelo = br.ReadByte(),
                                nAvgTemp = br.ReadByte(),
                                nTempChg = br.ReadByte(),
                                U5b = br.ReadByte(),
                                DisLFLine = br.ReadInt16(),
                                DisLeft = br.ReadInt16(),
                                DisLFGap = br.ReadInt16(),
                                DisCenter = br.ReadInt16(),
                                DisRFGap = br.ReadInt16(),
                                DisRight = br.ReadInt16(),
                                DisRFLine = br.ReadInt16(),
                                HeiLFLine = br.ReadByte(),
                                HeiLeft = br.ReadByte(),
                                HeiLFGap = br.ReadByte(),
                                HeiCenter = br.ReadByte(),
                                HeiRFGap = br.ReadByte(),
                                HeiRight = br.ReadByte(),
                                HeiRFLine = br.ReadByte(),
                                WindDirToLF = br.ReadByte(),
                                WindDirToCF = br.ReadByte(),
                                WindDirToRF = br.ReadByte(),
                                WindDirLFToRF = br.ReadByte(),
                                WindDirFromLF = br.ReadByte(),
                                WindDirFromCF = br.ReadByte(),
                                WindDirFromRF = br.ReadByte(),
                                WindDirRFToLF = br.ReadByte(),
                                WindDirNone = br.ReadByte(),
                                nRainFreq = br.ReadByte(),
                                unk2b = br.ReadByte(),
                                LHSingles = br.ReadInt16(),
                                LHDoubles = br.ReadInt16(),
                                LHTriples = br.ReadInt16(),
                                LHHr = br.ReadInt16(),
                                Gap = br.ReadBytes(6),
                                RHSingles = br.ReadInt16(),
                                RHDoubles = br.ReadInt16(),
                                RHTriples = br.ReadInt16(),
                                RHHr = br.ReadInt16(),
                                End = br.ReadBytes(8),
                            });
                        }//while

                        br.Close();
                    }
                }
                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }//if

            //////////
            var nuetral = readList.Where(x => x.UID == 0 && x.ID == 0 && x.Year == 0);
            readList = readList.Where(x => x.UID != 0 && x.Year != -1).ToList();
            readList.AddRange(nuetral);
            /////////
            return readList;
        }

        public IEnumerable<Park> GetParks12(string path)//Park 154 bytes
        {
            var sendpath = path + "\\DMBPARK.IDX";
            GETIDXONEA(sendpath);
            List<Park> readList = new List<Park>();
            path += "\\DMBPARK.DAT";
            if (path != null && File.Exists(path))
            {
                try
                {
                    RC++;
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
                    {
                        br.BaseStream.Position = Ind + 2;//2466
                        var stop = (RC * 186) + Ind;
                        while (br.BaseStream.Position < br.BaseStream.Length - 154)
                        {
                            readList.Add(new Park
                            {
                                ID = br.ReadInt16(),
                                UID = br.ReadInt16(),
                                Year = br.ReadInt16(),
                                nParkN = br.ReadBytes(30),//38
                                nCity = br.ReadBytes(16),//70
                                nFilena = br.ReadBytes(32),
                                U1 = br.ReadBytes(32),
                                nCover = br.ReadByte(),
                                nSurface = br.ReadByte(),
                                nFoul = br.ReadByte(),
                                nTZ = br.ReadByte(),
                                nAvgWndVelo = br.ReadByte(),
                                nAvgTemp = br.ReadByte(),
                                nTempChg = br.ReadByte(),
                                U5b = br.ReadByte(),
                                DisLFLine = br.ReadInt16(),
                                DisLeft = br.ReadInt16(),
                                DisLFGap = br.ReadInt16(),
                                DisCenter = br.ReadInt16(),
                                DisRFGap = br.ReadInt16(),
                                DisRight = br.ReadInt16(),
                                DisRFLine = br.ReadInt16(),
                                HeiLFLine = br.ReadByte(),
                                HeiLeft = br.ReadByte(),
                                HeiLFGap = br.ReadByte(),
                                HeiCenter = br.ReadByte(),
                                HeiRFGap = br.ReadByte(),
                                HeiRight = br.ReadByte(),
                                HeiRFLine = br.ReadByte(),
                                WindDirToLF = br.ReadByte(),
                                WindDirToCF = br.ReadByte(),
                                WindDirToRF = br.ReadByte(),
                                WindDirLFToRF = br.ReadByte(),
                                WindDirFromLF = br.ReadByte(),
                                WindDirFromCF = br.ReadByte(),
                                WindDirFromRF = br.ReadByte(),
                                WindDirRFToLF = br.ReadByte(),
                                WindDirNone = br.ReadByte(),
                                nRainFreq = br.ReadByte(),
                                unk2b = br.ReadByte(),
                                LHSingles = br.ReadInt16(),
                                LHDoubles = br.ReadInt16(),
                                LHTriples = br.ReadInt16(),
                                LHHr = br.ReadInt16(),
                                Gap = br.ReadBytes(6),
                                RHSingles = br.ReadInt16(),
                                RHDoubles = br.ReadInt16(),
                                RHTriples = br.ReadInt16(),
                                RHHr = br.ReadInt16(),
                                End = br.ReadBytes(8),
                            });
                        }//while
                        br.Close();
                    }
                }
                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }//if

            //////////
            var nuetral = readList.Where(x => x.UID == 0 && x.ID == 0 && x.Year == 0);
            readList = readList.Where(x => x.UID != 0 && x.Year != -1).ToList();
            readList.AddRange(nuetral);
            /////////

            return readList;
        }

        public IEnumerable<DMBTransactions> Transactions(string path, string set)
        {

            List<DMBTransactions> readList = new List<DMBTransactions>();
            var usepath = path + "\\DMBRTLOG.DAT";
            if (set == "1")
            {
                usepath = path + "\\DMBGTLOG.DAT";
            }

            if (usepath != null && RC > 0 && File.Exists(usepath))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(usepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        br.BaseStream.Position = 2268; //4304
                        var len = br.BaseStream.Length;
                        while (br.BaseStream.Position < len - 28) //2152
                        {
                            readList.Add(new DMBTransactions
                            {
                                ActFlag = br.ReadInt16(),
                                Unk0 = br.ReadInt16(),
                                Action = br.ReadByte(), //0 = disabled list 1 = activated from disabled list 2 = demoted 3 = promoted 12 = placed on restricted list 19 = day to day
                                LeagNoa = br.ReadByte(),
                                Unk1 = br.ReadInt16(),
                                TRYear = br.ReadInt16(),
                                TRMonth = br.ReadByte(),
                                TRDay = br.ReadByte(),
                                EffYear = br.ReadInt16(),
                                EffMonth = br.ReadByte(),
                                EffDay = br.ReadByte(),
                                TTime = br.ReadByte(),
                                Unk2 = br.ReadByte(),
                                playno = br.ReadInt16(),
                                PlayerUID = br.ReadInt32(),
                                teamID = br.ReadInt16(),
                                oTeamID = br.ReadInt16(),
                            });
                        }
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            return readList;
        }

        public IEnumerable<DMBTransactions> Transactions12(string path, string set)
        {
            List<DMBTransactions> readList = new List<DMBTransactions>();
            var usepath = path + "\\DMBRTLOG.DAT";
            if (set == "1")
            {
                usepath = path + "\\DMBGTLOG.DAT";
            }

            if (usepath != null && RC > 0 && File.Exists(usepath))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(usepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        br.BaseStream.Position = 2240; //4304
                        while (br.BaseStream.Position < br.BaseStream.Length - 28) //2152
                        {
                            readList.Add(new DMBTransactions
                            {
                                ActFlag = br.ReadInt16(),
                                Unk0 = br.ReadInt16(),
                                Action = br.ReadByte(), //0 = disabled list 1 = activated from disabled list 2 = demoted 3 = promoted 12 = placed on restricted list 19 = day to day
                                LeagNoa = br.ReadByte(),
                                Unk1 = br.ReadInt16(),
                                TRYear = br.ReadInt16(),
                                TRMonth = br.ReadByte(),
                                TRDay = br.ReadByte(),
                                EffYear = br.ReadInt16(),
                                EffMonth = br.ReadByte(),
                                EffDay = br.ReadByte(),
                                TTime = br.ReadByte(),
                                Unk2 = br.ReadByte(),
                                playno = br.ReadInt16(),
                                PlayerUID = br.ReadInt32(),
                                teamID = br.ReadInt16(),
                                oTeamID = br.ReadInt16(),
                            });
                        }
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            return readList;
        }

        public IEnumerable<Injury> Injuries(string path/*, string set*/)
        {
            List<Injury> readList = new List<Injury>();
            var usepath = path + "\\dmbinj.dat";
            try
            {
                if (usepath != null && File.Exists(usepath))
                {
                    try
                    {
                        using (BinaryReader br = new BinaryReader(new FileStream(usepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        {
                            br.BaseStream.Position = 19; //4304
                            while (br.BaseStream.Position < br.BaseStream.Length - 18) //2152
                            {
                                readList.Add(new Injury
                                {
                                    A9 = br.ReadByte(),
                                    Year = br.ReadInt16(),
                                    Month = br.ReadByte(),
                                    Day = br.ReadByte(),
                                    HomeTeamID = br.ReadInt16(),
                                    VisitorTeamID = br.ReadInt16(),
                                    gody = br.ReadByte(),
                                    Post = br.ReadByte(),
                                    PlayerTeamID = br.ReadInt16(),
                                    PlayerTeam = br.ReadInt16(),
                                    Type = br.ReadByte(),
                                    Dur = br.ReadByte(),
                                    Dura = br.ReadByte(),
                                });
                            }
                            br.Close();
                        }
                    }

                    catch (System.IO.EndOfStreamException e)
                    {
                        var lbl = "Error: " + e.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }

                    catch (Exception ex)
                    {
                        var lbl = "Error: " + ex.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            readList = readList.Where(x => x.Year > 1850 && x.Year < 2050 && x.Month > 0 && x.Month < 13).ToList();
            return readList;
        }

        public IEnumerable<Schedule> GetOrgSchedule(string path, string scopeselect)
        {
            List<OrgData> lge = new List<OrgData>();
            lge = GetOrg(path);
            var dat = "";
            var lgmonth = "";
            var lgday = "";
            var lgyear = "";
            var trlu = "";
            var OrgName = "";
            List<DMBSG> readList = new List<DMBSG>();

            if (lge != null && lge.FirstOrDefault().Name == scopeselect)
            {
                dat = lge.FirstOrDefault().DATFile;
                lgmonth = lge.FirstOrDefault().LGMonth;
                lgday = lge.FirstOrDefault().LGDay;
                lgyear = lge.FirstOrDefault().LGYear;
                trlu = lge.FirstOrDefault().TRLU;
                OrgName = lge.FirstOrDefault().Name;

                string sendpath;
                if (Convert.ToInt32(dat) < 10) sendpath = path + "\\DMBSG0" + dat + ".IDX";
                else sendpath = path + "\\DMBSG" + dat + ".IDX";
                GETIDX(sendpath);
                string bpath;
                if (Convert.ToInt32(dat) < 10) bpath = path + "\\DMBSG0" + dat + ".DAT";
                else bpath = path + "\\DMBSG" + dat + ".DAT";

                if (bpath != null && File.Exists(bpath))
                {
                    try
                    {
                        using (BinaryReader br = new BinaryReader(new FileStream(bpath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        {
                            br.BaseStream.Position = 4; //4304
                            while (br.BaseStream.Position < br.BaseStream.Length - 268) //2152
                            {
                                readList.Add(new DMBSG
                                {
                                    Year = br.ReadInt16(),
                                    Month = br.ReadByte(),
                                    Day = br.ReadByte(),
                                    HomeTeamID = br.ReadInt16(),
                                    VisitorTeamID = br.ReadInt16(),
                                    GameofDay = br.ReadByte(),
                                    GmType = br.ReadByte(),
                                    Unk1 = br.ReadBytes(3),
                                    played = br.ReadByte(),
                                    Unk2 = br.ReadBytes(24),//24
                                    VLU = br.ReadBytes(18),
                                    VLUP = br.ReadBytes(9),
                                    GAP = br.ReadByte(),
                                    VPit = br.ReadInt16(),///////////////////////////////////////
                                    HLU = br.ReadBytes(18),
                                    HLUP = br.ReadBytes(9),
                                    GUP = br.ReadByte(),
                                    HPit = br.ReadInt16(),
                                    T1 = br.ReadByte(),
                                    T1a = br.ReadByte(),
                                    GTemp = br.ReadInt16(),
                                    T3 = br.ReadInt16(),
                                    GField = br.ReadByte(),
                                    GSky = br.ReadByte(),
                                    T5 = br.ReadInt16(),
                                    T6 = br.ReadInt16(),
                                    T7 = br.ReadInt16(),
                                    T8 = br.ReadInt16(),
                                    T9 = br.ReadInt16(),
                                    GRainDelay = br.ReadInt16(),
                                    T11 = br.ReadInt16(),
                                    T12 = br.ReadInt16(),
                                    T13 = br.ReadInt16(),
                                    T14 = br.ReadInt16(),
                                    T15 = br.ReadInt16(),
                                    GWindDir = br.ReadInt16(),
                                    T17 = br.ReadInt16(),
                                    GWindSpeed = br.ReadInt16(),
                                    T19 = br.ReadInt16(),
                                    Inn = br.ReadByte(),
                                    VS = br.ReadBytes(40),
                                    HS = br.ReadBytes(40),
                                    extra = br.ReadByte(),
                                    VisStarter = br.ReadInt16(),
                                    HomeStarter = br.ReadInt16(),
                                    VHand = br.ReadByte(),
                                    HHand = br.ReadByte(),
                                    WinP = br.ReadInt16(),
                                    LoseP = br.ReadInt16(),////////////////////////////////////////////////////////////
                                    SaveP = br.ReadInt16(),
                                    GWRBI = br.ReadInt16(),
                                    Surface = br.ReadByte(),
                                    VisLOB = br.ReadByte(),
                                    HomLOB = br.ReadByte(),
                                    VisDP = br.ReadByte(),
                                    HomDP = br.ReadByte(),
                                    B19 = br.ReadBytes(2),
                                    Unk51 = br.ReadBytes(29),
                                    LGMonth = lgmonth,
                                    LGMDay = lgday,
                                    OrgName = OrgName,
                                });
                            }
                            br.Close();
                        }
                    }

                    catch (System.IO.EndOfStreamException e)
                    {
                        var lbl = "Error: " + e.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }

                    catch (Exception ex)
                    {
                        var lbl = "Error: " + ex.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }
                }
            }
            else // league dat file used for schedule
            {
                List<DMBSG> readList2 = new List<DMBSG>();

                List<DMBLeague> lea = new List<DMBLeague>();

                lea = League(path).ToList(); //get the list of leagues

                lea = lea.Where(x => x.LeagueName == scopeselect).ToList();//new
                //
                foreach (var i in lea)
                {
                    string bpath;
                    if (Convert.ToInt32(i.DatFile) < 10) bpath = path + "\\DMBSG0" + i.DatFile + ".DAT";
                    else bpath = path + "\\DMBSG" + i.DatFile + ".DAT";
                    readList2 = LeagueSched(bpath).ToList();

                    lgmonth = i.LGMonth.ToString();
                    lgday = i.LGDay.ToString();
                    lgyear = i.LGMYear.ToString();
                    trlu = i.TrLi.ToString();
                    readList.AddRange((IEnumerable<DMBSG>)readList2);
                    readList2.Clear();
                }
            }
            List<Schedule> sched = new List<Schedule>();
            readList = readList.Where(x => x.Year > 1876 && x.Year < 2100).ToList();
            try
            {
                foreach (var i in readList)
                {
                    sched.Add(new Schedule
                    {
                        Date = Convert.ToDateTime(i.Month + "/" + i.Day + "/" + i.Year, CultureInfo.InvariantCulture),
                        GameOfDay = i.GameofDay,
                        Inn = i.Inn.ToString(),
                        VisitorTeam = i.VisitorTeamID.ToString(),
                        VisitorStarter = i.VisStarter.ToString(),
                        VisitorScore = i.VisScore,
                        HomeTeam = i.HomeTeamID.ToString(),
                        HomeStarter = i.HomeStarter.ToString(),
                        HomeScore = i.HomeScore,
                        Win = i.WinP.ToString(),
                        Loss = i.LoseP.ToString(),
                        Save = i.SaveP.ToString(),
                        GWRBI = i.GWRBI.ToString(),
                        filename = i.filename,
                        played = i.played,
                        LastGame = Convert.ToDateTime(lgmonth + "/" + lgday + "/" + lgyear, CultureInfo.InvariantCulture),
                        TRLU = trlu,
                        VPit = i.VPit.ToString(),
                        HPit = i.HPit.ToString(),
                        GmType = i.GmType.ToString(),
                        OrgName = i.OrgName,
                        Month = i.Month,
                        Day = i.Day,
                        Year = i.Year,
                        VHand = i.VHand,
                        HHand = i.HHand,
                        VS = i.VS,
                        HS = i.HS,
                        GTemp = i.GTemp.ToString(),
                        GField = i.GField.ToString(),
                        GRainDelay = i.GRainDelay.ToString(),
                        GSky = i.GSky.ToString(),
                        GWindDir = i.GWindDir.ToString(),
                        GWindSpeed = i.GWindSpeed.ToString(),
                        VisLOB = i.VisLOB,
                        HomLOB = i.HomLOB,
                        VisDP = i.VisDP,
                        HomDP = i.HomDP,
                        VLU = i.VLU,
                        VLUP = i.VLUP,
                        HLU = i.HLU,
                        HLUP = i.HLUP,
                    });
                }
                return sched;
            }
            catch (Exception e)
            {
                var lbl = "Error: " + e.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
                return null;
            }
        }

        public IEnumerable<Schedule> GetOrgSchedule12(string path, string scopeselect)
        {
            List<OrgData> lge = new List<OrgData>();
            lge = GetOrg12(path, scopeselect);
            var dat = "";
            var lgmonth = "";
            var lgday = "";
            var lgyear = "";
            var trlu = "";
            var OrgName = "";
            List<DMBSG> readList = new List<DMBSG>();

            if (lge != null && lge.FirstOrDefault().Name == scopeselect)
            {
                dat = lge.FirstOrDefault().DATFile;
                lgmonth = lge.FirstOrDefault().LGMonth;
                lgday = lge.FirstOrDefault().LGDay;
                lgyear = lge.FirstOrDefault().LGYear;
                trlu = lge.FirstOrDefault().TRLU;
                OrgName = lge.FirstOrDefault().Name;
                if (lgmonth == "0") lgmonth = "4";
                if (lgday == "0") lgday = "6";
                if (lgyear == "0") lgyear = "1900";

                string sendpath;
                if (Convert.ToInt32(dat) < 10) sendpath = path + "\\DMBSG0" + dat + ".IDX";
                else sendpath = path + "\\DMBSG" + dat + ".IDX";
                GETIDX(sendpath);
                string bpath;
                if (Convert.ToInt32(dat) < 10) bpath = path + "\\DMBSG0" + dat + ".DAT";
                else bpath = path + "\\DMBSG" + dat + ".DAT";

                if (bpath != null && File.Exists(bpath))
                {
                    try
                    {
                        using (BinaryReader br = new BinaryReader(new FileStream(bpath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        {
                            br.BaseStream.Position = 2724; //4304
                            while (br.BaseStream.Position < br.BaseStream.Length - 268) //272
                            {
                                readList.Add(new DMBSG
                                {
                                    Year = br.ReadInt16(),
                                    Month = br.ReadByte(),
                                    Day = br.ReadByte(),
                                    HomeTeamID = br.ReadInt16(),
                                    VisitorTeamID = br.ReadInt16(),
                                    GameofDay = br.ReadByte(),
                                    GmType = br.ReadByte(),
                                    Unk1 = br.ReadBytes(3),
                                    played = br.ReadByte(),
                                    Unk2 = br.ReadBytes(26),
                                    VLU = br.ReadBytes(18),
                                    VLUP = br.ReadBytes(9),
                                    GAP = br.ReadByte(),
                                    VPit = br.ReadInt16(),///////////////////////////////////////
                                    HLU = br.ReadBytes(18),
                                    HLUP = br.ReadBytes(9),
                                    GUP = br.ReadByte(),
                                    HPit = br.ReadInt16(),
                                    GTemp = br.ReadInt16(),
                                    T3 = br.ReadInt16(),
                                    GField = br.ReadByte(),
                                    GSky = br.ReadByte(),
                                    T5 = br.ReadInt16(),
                                    T6 = br.ReadInt16(),
                                    T7 = br.ReadInt16(),
                                    T8 = br.ReadInt16(),
                                    T9 = br.ReadInt16(),
                                    GRainDelay = br.ReadInt16(),
                                    T11 = br.ReadInt16(),
                                    T12 = br.ReadInt16(),
                                    T13 = br.ReadInt16(),
                                    T14 = br.ReadInt16(),
                                    T15 = br.ReadInt16(),
                                    GWindDir = br.ReadInt16(),
                                    T17 = br.ReadInt16(),
                                    GWindSpeed = br.ReadInt16(),
                                    T19 = br.ReadInt16(),
                                    Inn = br.ReadByte(),
                                    VS = br.ReadBytes(40),
                                    HS = br.ReadBytes(40),
                                    extra = br.ReadByte(),
                                    VisStarter = br.ReadInt16(),
                                    HomeStarter = br.ReadInt16(),
                                    VHand = br.ReadByte(),
                                    HHand = br.ReadByte(),
                                    WinP = br.ReadInt16(),
                                    LoseP = br.ReadInt16(),////////////////////////////////////////////////////////////
                                    SaveP = br.ReadInt16(),
                                    GWRBI = br.ReadInt16(),
                                    Surface = br.ReadByte(),
                                    VisLOB = br.ReadByte(),
                                    HomLOB = br.ReadByte(),
                                    VisDP = br.ReadByte(),
                                    HomDP = br.ReadByte(),
                                    B19 = br.ReadBytes(6),
                                    Unk51 = br.ReadBytes(29),
                                    LGMonth = lgmonth,
                                    LGMDay = lgday,
                                    LGMYear = Convert.ToInt16(lgyear),
                                    OrgName = OrgName,
                                });
                            }
                            br.Close();
                        }
                    }

                    catch (System.IO.EndOfStreamException e)
                    {
                        var lbl = "Error: " + e.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }

                    catch (Exception ex)
                    {
                        var lbl = "Error: " + ex.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }
                }
            }
            else  // league dat file used for schedule
            {
                List<DMBSG> readList2 = new List<DMBSG>();
                List<DMBLeague> lea = new List<DMBLeague>();

                lea = League12(path).ToList(); //get the list of leagues
                lea = lea.Where(x => x.LeagueName == scopeselect).ToList();//new
                foreach (var i in lea)
                {
                    string bpath;
                    if (Convert.ToInt32(i.DatFile) < 10) bpath = path + "\\DMBSG0" + i.DatFile + ".DAT";
                    else bpath = path + "\\DMBSG" + i.DatFile + ".DAT";

                    readList2 = LeagueSched12(bpath).ToList();

                    lgmonth = i.LGMonth.ToString();
                    lgday = i.LGDay.ToString();
                    lgyear = i.LGMYear.ToString();
                    trlu = i.TrLi.ToString();
                    readList.AddRange((IEnumerable<DMBSG>)readList2);
                    readList2.Clear();
                }
            }
            List<Schedule> sched = new List<Schedule>();
            readList = readList.Where(x => x.Year > 1870 && x.Year < 2080).ToList();
            try
            {
                foreach (var i in readList)
                {
                    sched.Add(new Schedule
                    {
                        Date = Convert.ToDateTime(i.Month + "/" + i.Day + "/" + i.Year, CultureInfo.InvariantCulture),
                        GameOfDay = i.GameofDay,
                        Inn = i.Inn.ToString(),
                        VisitorTeam = i.VisitorTeamID.ToString(),
                        VisitorStarter = i.VisStarter.ToString(),
                        VisitorScore = i.VisScore,
                        played = i.played,
                        HomeTeam = i.HomeTeamID.ToString(),
                        HomeStarter = i.HomeStarter.ToString(),
                        HomeScore = i.HomeScore,
                        Win = i.WinP.ToString(),
                        Loss = i.LoseP.ToString(),
                        Save = i.SaveP.ToString(),
                        GWRBI = i.GWRBI.ToString(),
                        filename = i.filename,
                        TRLU = trlu,
                        VPit = i.VPit.ToString(),
                        HPit = i.HPit.ToString(),
                        VHand = i.VHand,
                        HHand = i.HHand,
                        GmType = i.GmType.ToString(),
                        OrgName = i.OrgName,
                        Month = i.Month,
                        Day = i.Day,
                        Year = i.Year,
                        VS = i.VS,
                        HS = i.HS,
                        GTemp = i.GTemp.ToString(),
                        GField = i.GField.ToString(),
                        GRainDelay = i.GRainDelay.ToString(),
                        GSky = i.GSky.ToString(),
                        GWindDir = i.GWindDir.ToString(),
                        GWindSpeed = i.GWindSpeed.ToString(),
                        VisLOB = i.VisLOB,
                        HomLOB = i.HomLOB,
                        VisDP = i.VisDP,
                        HomDP = i.HomDP,
                        VLU = i.VLU,
                        VLUP = i.VLUP,
                        HLU = i.HLU,
                        HLUP = i.HLUP,
                    });
                }
                return sched;
            }
            catch (FormatException)
            {
                return null;
            }
            catch (Exception e)
            {
                var lbl = "Error: " + e.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
                return null;
            }
        }

        public IEnumerable<Schedule> MyScheduleLoadOld(string path)
        {
            List<Schedule> binary = new List<Schedule>();
            string filename;
            if (path.Substring(path.Length - 3) == "dat") filename = path;
            else filename = path + "\\scheduledpitchers.dat";

            if (File.Exists(filename))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        while (br.BaseStream.Position != br.BaseStream.Length)
                        {
                            binary.Add(new Schedule
                            {
                                Month = br.ReadByte(),
                                Day = br.ReadByte(),
                                Year = br.ReadInt16(),
                                GameOfDay = br.ReadByte(),
                                VisitorTeamAbbr = br.ReadString(),
                                VisitorStarter = br.ReadString(),
                                HomeTeamAbbr = br.ReadString(),
                                HomeStarter = br.ReadString(),
                                Inn = br.ReadString(),
                            });
                        }
                }
                catch (Exception)
                {
                    var lbl = "Error: Old pitcher's dat file encountered. It has been deleted.";
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                    File.Delete(filename);//previous version of the dat file encountered
                }
            }
            foreach (var i in binary)
            {
                i.Date = DateTime.Parse(i.Month + "/" + i.Day + "/" + i.Year);
                i.Opp = i.VisitorTeamAbbr;
            }

            return binary;
        }

        public IEnumerable<Schedule> MyScheduleLoad(string path)
        {
            List<Schedule> binary = new List<Schedule>();
            string filename;
            if (path.Substring(path.Length - 3) == "dat") filename = path;
            else filename = path + "\\scheduledpitchers.dat";

            if (File.Exists(filename))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        while (br.BaseStream.Position != br.BaseStream.Length)
                        {
                            binary.Add(new Schedule
                            {

                                Month = br.ReadByte(),
                                Day = br.ReadByte(),
                                Year = br.ReadInt16(),
                                GameOfDay = br.ReadByte(),
                                VisitorTeamAbbr = br.ReadString(),
                                VisitorStarter = br.ReadString(),
                                HomeTeamAbbr = br.ReadString(),
                                HomeStarter = br.ReadString(),
                                Inn = br.ReadString(),
                                xVisitorStarter = br.ReadString(),
                                xHomeStarter = br.ReadString(),
                            });
                        }
                }
                catch
                {
                    List<Schedule> savelist = MyScheduleLoadOld(path).ToList();
                    MyScheduleSave(path, savelist);
                    binary = MyScheduleReLoad(path).ToList();
                }
            }
            foreach (var i in binary)
            {
                i.Date = DateTime.Parse(i.Month + "/" + i.Day + "/" + i.Year);
                i.Opp = i.VisitorTeamAbbr;
            }

            return binary;
        }

        public IEnumerable<Schedule> MyScheduleReLoad(string path)
        {
            List<Schedule> binary = new List<Schedule>();
            string filename;
            if (path.Substring(path.Length - 3) == "dat") filename = path;
            else filename = path + "\\scheduledpitchers.dat";

            if (File.Exists(filename))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        while (br.BaseStream.Position != br.BaseStream.Length)
                        {
                            binary.Add(new Schedule
                            {
                                Month = br.ReadByte(),
                                Day = br.ReadByte(),
                                Year = br.ReadInt16(),
                                GameOfDay = br.ReadByte(),
                                VisitorTeamAbbr = br.ReadString(),
                                VisitorStarter = br.ReadString(),
                                HomeTeamAbbr = br.ReadString(),
                                HomeStarter = br.ReadString(),
                                Inn = br.ReadString(),
                                xVisitorStarter = br.ReadString(),
                                xHomeStarter = br.ReadString(),
                            });
                        }
                }
                catch
                {
                }
            }
            foreach (var i in binary)
            {
                i.Date = DateTime.Parse(i.Month + "/" + i.Day + "/" + i.Year);
                i.Opp = i.VisitorTeamAbbr;
            }
            return binary;
        }


        public void MyScheduleSave(string path, List<Schedule> savelist)
        {
            foreach (var i in savelist)
            {
                if (i.Inn == null) i.Inn = "";
                if (i.HomeStarter == null) i.HomeStarter = "";
                if (i.VisitorStarter == null) i.VisitorStarter = "";
            }

            var filename = path + "\\scheduledpitchers.dat";
            if (File.Exists(filename))
            {
                File.Delete(filename);
            }
            try
            {
                using (BinaryWriter bw = new BinaryWriter(new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))) //1076 
                    foreach (var i in savelist)
                    {
                        if (i.xVisitorStarter == null) i.xVisitorStarter = "";
                        if (i.xHomeStarter == null) i.xHomeStarter = "";
                        bw.Write((byte)i.Month);
                        bw.Write((byte)i.Day);
                        bw.Write((short)i.Year);
                        bw.Write((byte)i.GameOfDay);
                        bw.Write(i.VisitorTeamAbbr);
                        bw.Write(i.VisitorStarter);
                        bw.Write(i.HomeTeamAbbr);
                        bw.Write(i.HomeStarter);
                        bw.Write(i.Inn);
                        bw.Write(i.xVisitorStarter);
                        bw.Write(i.xHomeStarter);
                    }
            }
            catch (Exception e)
            {
                var lbl = "Error: " + e.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
        }

        public IEnumerable<DMBSG> LeagueSched(string path)
        {
            var sendpath = path.Replace("DAT", "IDX");
            GETIDX(sendpath);
            List<DMBSG> readList = new List<DMBSG>();

            try
            {
                using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                {
                    br.BaseStream.Position = Ind + 4; //4304
                    var Iter = RC * 268 + Ind;
                    while (br.BaseStream.Position < Iter) //2152
                    {
                        readList.Add(new DMBSG
                        {
                            Year = br.ReadInt16(),
                            Month = br.ReadByte(),
                            Day = br.ReadByte(),
                            HomeTeamID = br.ReadInt16(),
                            VisitorTeamID = br.ReadInt16(),
                            GameofDay = br.ReadByte(),
                            GmType = br.ReadByte(),
                            Unk1 = br.ReadBytes(3),
                            played = br.ReadByte(),
                            Unk2 = br.ReadBytes(24),
                            VLU = br.ReadBytes(18),
                            VLUP = br.ReadBytes(9),
                            GAP = br.ReadByte(),
                            VPit = br.ReadInt16(),///////////////////////////////////////
                            HLU = br.ReadBytes(18),
                            HLUP = br.ReadBytes(9),
                            GUP = br.ReadByte(),
                            HPit = br.ReadInt16(),
                            T1 = br.ReadByte(),
                            T1a = br.ReadByte(),
                            GTemp = br.ReadInt16(),
                            T3 = br.ReadInt16(),
                            GField = br.ReadByte(),
                            GSky = br.ReadByte(),
                            T5 = br.ReadInt16(),
                            T6 = br.ReadInt16(),
                            T7 = br.ReadInt16(),
                            T8 = br.ReadInt16(),
                            T9 = br.ReadInt16(),
                            GRainDelay = br.ReadInt16(),
                            T11 = br.ReadInt16(),
                            T12 = br.ReadInt16(),
                            T13 = br.ReadInt16(),
                            T14 = br.ReadInt16(),
                            T15 = br.ReadInt16(),
                            GWindDir = br.ReadInt16(),
                            T17 = br.ReadInt16(),
                            GWindSpeed = br.ReadInt16(),
                            T19 = br.ReadInt16(),
                            Inn = br.ReadByte(),
                            VS = br.ReadBytes(40),
                            HS = br.ReadBytes(40),
                            extra = br.ReadByte(),
                            VisStarter = br.ReadInt16(),
                            HomeStarter = br.ReadInt16(),
                            VHand = br.ReadByte(),
                            HHand = br.ReadByte(),
                            WinP = br.ReadInt16(),
                            LoseP = br.ReadInt16(),////////////////////////////////////////////////////////////
                            SaveP = br.ReadInt16(),
                            GWRBI = br.ReadInt16(),
                            Surface = br.ReadByte(),
                            VisLOB = br.ReadByte(),
                            HomLOB = br.ReadByte(),
                            VisDP = br.ReadByte(),
                            HomDP = br.ReadByte(),
                            B19 = br.ReadBytes(2),
                            Unk51 = br.ReadBytes(29),
                        });
                    }
                    br.Close();
                }
            }

            catch (System.IO.EndOfStreamException e)
            {
                var lbl = "Error: " + e.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }

            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            return readList;
        }

        public IEnumerable<DMBSG> LeagueSched12(string path)
        {
            var sendpath = path.Replace("DAT", "IDX");
            GETIDX(sendpath);
            List<DMBSG> readList = new List<DMBSG>();

            try
            {
                using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                {
                    br.BaseStream.Position = 2724; //4304
                    while (br.BaseStream.Position < br.BaseStream.Length - 272) //272
                    {
                        readList.Add(new DMBSG
                        {
                            Year = br.ReadInt16(),
                            Month = br.ReadByte(),
                            Day = br.ReadByte(),
                            HomeTeamID = br.ReadInt16(),
                            VisitorTeamID = br.ReadInt16(),
                            GameofDay = br.ReadByte(),
                            GmType = br.ReadByte(),
                            Unk1 = br.ReadBytes(3),
                            played = br.ReadByte(),
                            Unk2 = br.ReadBytes(26),
                            VLU = br.ReadBytes(18),
                            VLUP = br.ReadBytes(9),
                            GAP = br.ReadByte(),
                            VPit = br.ReadInt16(),///////////////////////////////////////
                            HLU = br.ReadBytes(18),
                            HLUP = br.ReadBytes(9),
                            GUP = br.ReadByte(),
                            HPit = br.ReadInt16(),
                            GTemp = br.ReadInt16(),
                            T3 = br.ReadInt16(),
                            GField = br.ReadByte(),
                            GSky = br.ReadByte(),
                            T5 = br.ReadInt16(),
                            T6 = br.ReadInt16(),
                            T7 = br.ReadInt16(),
                            T8 = br.ReadInt16(),
                            T9 = br.ReadInt16(),
                            GRainDelay = br.ReadInt16(),
                            T11 = br.ReadInt16(),
                            T12 = br.ReadInt16(),
                            T13 = br.ReadInt16(),
                            T14 = br.ReadInt16(),
                            T15 = br.ReadInt16(),
                            GWindDir = br.ReadInt16(),
                            T17 = br.ReadInt16(),
                            GWindSpeed = br.ReadInt16(),
                            T19 = br.ReadInt16(),
                            Inn = br.ReadByte(),
                            VS = br.ReadBytes(40),
                            HS = br.ReadBytes(40),
                            extra = br.ReadByte(),
                            VisStarter = br.ReadInt16(),
                            HomeStarter = br.ReadInt16(),
                            VHand = br.ReadByte(),
                            HHand = br.ReadByte(),
                            WinP = br.ReadInt16(),
                            LoseP = br.ReadInt16(),////////////////////////////////////////////////////////////
                            SaveP = br.ReadInt16(),
                            GWRBI = br.ReadInt16(),
                            Surface = br.ReadByte(),
                            VisLOB = br.ReadByte(),
                            HomLOB = br.ReadByte(),
                            VisDP = br.ReadByte(),
                            HomDP = br.ReadByte(),
                            B19 = br.ReadBytes(6),
                            Unk51 = br.ReadBytes(29),
                        });
                    }
                    br.Close();
                }
            }

            catch (System.IO.EndOfStreamException e)
            {
                var lbl = "Error: " + e.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }

            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            return readList;
        }

        public List<OrgData> GetOrg(string path)
        {
            List<DMBOrg> readList = new List<DMBOrg>();
            var sendpath = path + "\\DMBORG.IDX";
            GETIDXONEA(sendpath);
            var Start = 1042;
            GETIDXONE(sendpath, Start);//datlist

            if (RC == 1) // Org was found, use it
            {
                var usepath = path + "\\DMBORG.DAT";
                if (usepath != null && File.Exists(usepath))
                {
                    try
                    {
                        using (BinaryReader br = new BinaryReader(new FileStream(usepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        {
                            foreach (var i in datlist)
                            {
                                br.BaseStream.Position = i.A1;
                                var stop = br.BaseStream.Position;
                                while (br.BaseStream.Position == stop) //2152
                                {
                                    readList.Add(new DMBOrg
                                    {
                                        ActFlag = br.ReadByte(),
                                        ActFlaga = br.ReadByte(),
                                        ID = br.ReadInt16(),
                                        UID = br.ReadInt16(),
                                        OrgYear = br.ReadInt16(),
                                        OrgName = br.ReadBytes(32),
                                        FrstLgeID = br.ReadInt16(),
                                        ScndlgeID = br.ReadInt16(),
                                        InterLge = br.ReadByte(),
                                        TRYearaa = br.ReadByte(),
                                        DATFile = br.ReadInt16(),
                                        GPT = br.ReadByte(),
                                        DHRule = br.ReadByte(),
                                        Injury = br.ReadByte(),
                                        SFRule = br.ReadByte(),
                                        WarmUp = br.ReadByte(),
                                        EffDay = br.ReadByte(),
                                        TRLU = br.ReadByte(),
                                        EffDay1 = br.ReadByte(),
                                        EffDaya = br.ReadByte(),
                                        EffDaya1 = br.ReadByte(),
                                        Format = br.ReadByte(),
                                        Boxscores = br.ReadByte(),
                                        Scoresheets = br.ReadByte(),
                                        GameLogs = br.ReadByte(),
                                        GameAccounts = br.ReadByte(),
                                        Unk2a = br.ReadByte(),
                                        playno = br.ReadByte(),
                                        TPA = br.ReadByte(),
                                        PAS = br.ReadByte(),
                                        GS = br.ReadByte(),
                                        BF = br.ReadByte(),
                                        IP = br.ReadByte(),
                                        FGBP = br.ReadByte(),
                                        PRF = br.ReadByte(),
                                        TPAPer = br.ReadInt16(),
                                        PASPer = br.ReadInt16(),
                                        GSPer = br.ReadInt16(),
                                        BFPer = br.ReadInt16(),
                                        IPPer = br.ReadInt16(),
                                        FGBPPer = br.ReadInt16(),
                                        PRFPer = br.ReadInt16(),
                                        Stage = br.ReadByte(),
                                        Unk9a = br.ReadByte(),
                                        LGYear = br.ReadInt16(),
                                        LGMonth = br.ReadByte(),
                                        LGDay = br.ReadByte(),
                                        Ex1 = br.ReadByte(),
                                        Ex2 = br.ReadByte(),
                                        Unk10 = br.ReadBytes(20),//34
                                        A1 = br.ReadByte(),
                                        A2 = br.ReadByte(),
                                        A3 = br.ReadByte(),
                                        A4 = br.ReadByte(),
                                        DivP = br.ReadByte(),
                                        CS = br.ReadByte(),
                                        WSGT = br.ReadByte(),
                                        Ax4 = br.ReadByte(),
                                    });
                                }
                            }
                            br.Close();
                        }
                    }

                    catch (System.IO.EndOfStreamException e)
                    {
                        var lbl = "Error: " + e.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }

                    catch (Exception ex)
                    {
                        var lbl = "Error: " + ex.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }
                }
                List<OrgData> odata = new List<OrgData>();

                if (readList != null && readList.Count() > 0)
                {
                    foreach (var i in readList)
                    {
                        odata.Add(new OrgData
                        {
                            Name = i.Name,
                            DATFile = i.DATFile.ToString(),
                            LGMonth = i.LGMonth.ToString(),
                            LGDay = i.LGDay.ToString(),
                            LGYear = i.LGYear.ToString(),
                            TRLU = i.TRLU.ToString(),
                        });
                    }
                    return odata;
                }
                else
                {
                    return null;  //add for leagues only instead of org.
                }
            }
            else  /// no organizations
            {
                return null;
            }
        }

        public List<OrgData> GetOrg12(string path, string scopeselect)
        {
            List<DMBOrg> readList = new List<DMBOrg>();
            var sendpath = path + "\\DMBORG.IDX";
            GETIDXONEA(sendpath);
            var Start = 1042;
            GETIDXONE(sendpath, Start);//datlist

            if (RC == 1)
            {
                var usepath = path + "\\DMBORG.DAT";
                if (usepath != null && File.Exists(usepath))
                {
                    try
                    {
                        using (BinaryReader br = new BinaryReader(new FileStream(usepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        {
                            foreach (var i in datlist)
                            {
                                br.BaseStream.Position = i.A1;
                                var stop = br.BaseStream.Position;
                                while (br.BaseStream.Position == stop) //2152
                                {
                                    readList.Add(new DMBOrg
                                    {
                                        ActFlag = br.ReadByte(),
                                        ActFlaga = br.ReadByte(),
                                        ID = br.ReadInt16(),
                                        UID = br.ReadInt16(),
                                        OrgYear = br.ReadInt16(),
                                        OrgName = br.ReadBytes(32),
                                        FrstLgeID = br.ReadInt16(),
                                        ScndlgeID = br.ReadInt16(),
                                        InterLge = br.ReadByte(),
                                        TRYearaa = br.ReadByte(),
                                        DATFile = br.ReadInt16(),
                                        GPT = br.ReadByte(),
                                        DHRule = br.ReadByte(),
                                        Injury = br.ReadByte(),
                                        SFRule = br.ReadByte(),
                                        WarmUp = br.ReadByte(),
                                        MPC = br.ReadByte(),
                                        IWR = br.ReadByte(),
                                        BPR = br.ReadByte(),
                                        EIRR = br.ReadByte(),
                                        EIRP = br.ReadByte(),
                                        UPC = br.ReadByte(),
                                        ILB = br.ReadByte(),
                                        ILP = br.ReadByte(),
                                        EffDay = br.ReadByte(),
                                        TRLU = br.ReadByte(),
                                        EffDay1 = br.ReadByte(),
                                        EffDaya = br.ReadByte(),
                                        EffDaya1 = br.ReadByte(),
                                        Format = br.ReadByte(),
                                        Boxscores = br.ReadByte(),
                                        Scoresheets = br.ReadByte(),
                                        GameLogs = br.ReadByte(),
                                        GameAccounts = br.ReadByte(),
                                        Unk2a = br.ReadByte(),
                                        playno = br.ReadByte(),
                                        TPA = br.ReadByte(),
                                        PAS = br.ReadByte(),
                                        GS = br.ReadByte(),
                                        BF = br.ReadByte(),
                                        IP = br.ReadByte(),
                                        FGBP = br.ReadByte(),
                                        PRF = br.ReadByte(),
                                        TPAPer = br.ReadInt16(),
                                        PASPer = br.ReadInt16(),
                                        GSPer = br.ReadInt16(),
                                        BFPer = br.ReadInt16(),
                                        IPPer = br.ReadInt16(),
                                        FGBPPer = br.ReadInt16(),
                                        PRFPer = br.ReadInt16(),
                                        Stage = br.ReadByte(),
                                        Unk9a = br.ReadByte(),
                                        LGYear = br.ReadInt16(),
                                        LGMonth = br.ReadByte(),
                                        LGDay = br.ReadByte(),
                                        Ex1 = br.ReadByte(),
                                        Ex2 = br.ReadByte(),
                                        Unk10 = br.ReadBytes(20),//34
                                        A1 = br.ReadByte(),
                                        A2 = br.ReadByte(),
                                        A3 = br.ReadByte(),
                                        A4 = br.ReadByte(),
                                        DivP = br.ReadByte(),
                                        CS = br.ReadByte(),
                                        WSGT = br.ReadByte(),
                                        Ax4 = br.ReadByte(),
                                    });
                                }
                            }
                            br.Close();
                        }
                    }

                    catch (System.IO.EndOfStreamException e)
                    {
                        var lbl = "Error: " + e.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }

                    catch (Exception ex)
                    {
                        var lbl = "Error: " + ex.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }
                }
                List<OrgData> odata = new List<OrgData>();

                if (readList != null && readList.Count() > 0)
                {
                    foreach (var i in readList)
                    {
                        odata.Add(new OrgData
                        {
                            Name = i.Name,
                            DATFile = i.DATFile.ToString(),
                            LGMonth = i.LGMonth.ToString(),
                            LGDay = i.LGDay.ToString(),
                            LGYear = i.LGYear.ToString(),
                            TRLU = i.TRLU.ToString(),
                        });
                    }
                    return odata;
                }
                else
                {
                    return null;  //add for leagues only instead of org.
                }
            }
            else  /// no organizations
            {
                return null;
            }
        }

        public List<DMBOrg> GetOrganization(string path)
        {
            List<DMBOrg> readList = new List<DMBOrg>();
            var sendpath = path + "\\DMBORG.IDX";
            GETIDXONEA(sendpath);
            var Start = 1042;
            GETIDXONE(sendpath, Start);//datlist

            if (RC == 1)
            {
                var usepath = path + "\\DMBORG.DAT";
                if (usepath != null && File.Exists(usepath))
                {
                    try
                    {
                        using (BinaryReader br = new BinaryReader(new FileStream(usepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        {
                            foreach (var i in datlist)
                            {
                                br.BaseStream.Position = i.A1;
                                var stop = br.BaseStream.Position;
                                while (br.BaseStream.Position == stop) //2152
                                {
                                    readList.Add(new DMBOrg
                                    {
                                        ActFlag = br.ReadByte(),
                                        ActFlaga = br.ReadByte(),
                                        ID = br.ReadInt16(),
                                        UID = br.ReadInt16(),
                                        OrgYear = br.ReadInt16(),
                                        OrgName = br.ReadBytes(32),
                                        FrstLgeID = br.ReadInt16(),
                                        ScndlgeID = br.ReadInt16(),
                                        InterLge = br.ReadByte(),
                                        TRYearaa = br.ReadByte(),
                                        DATFile = br.ReadInt16(),
                                        GPT = br.ReadByte(),
                                        DHRule = br.ReadByte(),
                                        Injury = br.ReadByte(),
                                        SFRule = br.ReadByte(),
                                        WarmUp = br.ReadByte(),
                                        EffDay = br.ReadByte(),
                                        TRLU = br.ReadByte(),
                                        EffDay1 = br.ReadByte(),
                                        EffDaya = br.ReadByte(),
                                        EffDaya1 = br.ReadByte(),
                                        Format = br.ReadByte(),
                                        Boxscores = br.ReadByte(),
                                        Scoresheets = br.ReadByte(),
                                        GameLogs = br.ReadByte(),
                                        GameAccounts = br.ReadByte(),
                                        Unk2a = br.ReadByte(),
                                        playno = br.ReadByte(),
                                        TPA = br.ReadByte(),
                                        PAS = br.ReadByte(),
                                        GS = br.ReadByte(),
                                        BF = br.ReadByte(),
                                        IP = br.ReadByte(),
                                        FGBP = br.ReadByte(),
                                        PRF = br.ReadByte(),
                                        TPAPer = br.ReadInt16(),
                                        PASPer = br.ReadInt16(),
                                        GSPer = br.ReadInt16(),
                                        BFPer = br.ReadInt16(),
                                        IPPer = br.ReadInt16(),
                                        FGBPPer = br.ReadInt16(),
                                        PRFPer = br.ReadInt16(),
                                        Stage = br.ReadByte(),
                                        Unk9a = br.ReadByte(),
                                        LGYear = br.ReadInt16(),
                                        LGMonth = br.ReadByte(),
                                        LGDay = br.ReadByte(),
                                        Ex1 = br.ReadByte(),
                                        Ex2 = br.ReadByte(),
                                        Unk10 = br.ReadBytes(20),//34
                                        A1 = br.ReadByte(),
                                        A2 = br.ReadByte(),
                                        A3 = br.ReadByte(),
                                        A4 = br.ReadByte(),
                                        DivP = br.ReadByte(),
                                        CS = br.ReadByte(),
                                        WSGT = br.ReadByte(),
                                        Ax4 = br.ReadByte(),
                                    });
                                }
                            }
                            br.Close();
                        }
                    }

                    catch (System.IO.EndOfStreamException e)
                    {
                        var lbl = "Error: " + e.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }

                    catch (Exception ex)
                    {
                        var lbl = "Error: " + ex.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }
                }

            }
            else  /// no organizations
            {
                return null;
            }
            return readList;
        }

        public List<DMBOrg> GetOrganization12(string path)
        {
            List<DMBOrg> readList = new List<DMBOrg>();
            var sendpath = path + "\\DMBORG.IDX";
            GETIDXONEA(sendpath);
            var Start = 1042;
            GETIDXONE(sendpath, Start);//datlist

            if (RC == 1)
            {
                var usepath = path + "\\DMBORG.DAT";
                if (usepath != null && File.Exists(usepath))
                {
                    try
                    {
                        using (BinaryReader br = new BinaryReader(new FileStream(usepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        {
                            foreach (var i in datlist)
                            {
                                br.BaseStream.Position = i.A1;
                                var stop = br.BaseStream.Position;
                                while (br.BaseStream.Position == stop) //2152
                                {
                                    readList.Add(new DMBOrg
                                    {
                                        ActFlag = br.ReadByte(),
                                        ActFlaga = br.ReadByte(),
                                        ID = br.ReadInt16(),
                                        UID = br.ReadInt16(),
                                        OrgYear = br.ReadInt16(),
                                        OrgName = br.ReadBytes(32),
                                        FrstLgeID = br.ReadInt16(),
                                        ScndlgeID = br.ReadInt16(),
                                        InterLge = br.ReadByte(),
                                        TRYearaa = br.ReadByte(),
                                        DATFile = br.ReadInt16(),
                                        GPT = br.ReadByte(),
                                        DHRule = br.ReadByte(),
                                        Injury = br.ReadByte(),
                                        SFRule = br.ReadByte(),
                                        WarmUp = br.ReadByte(),
                                        MPC = br.ReadByte(),
                                        IWR = br.ReadByte(),
                                        BPR = br.ReadByte(),
                                        EIRR = br.ReadByte(),
                                        EIRP = br.ReadByte(),
                                        UPC = br.ReadByte(),
                                        ILB = br.ReadByte(),
                                        ILP = br.ReadByte(),
                                        EffDay = br.ReadByte(),
                                        TRLU = br.ReadByte(),
                                        EffDay1 = br.ReadByte(),
                                        EffDaya = br.ReadByte(),
                                        EffDaya1 = br.ReadByte(),
                                        Format = br.ReadByte(),
                                        Boxscores = br.ReadByte(),
                                        Scoresheets = br.ReadByte(),
                                        GameLogs = br.ReadByte(),
                                        GameAccounts = br.ReadByte(),
                                        Unk2a = br.ReadByte(),
                                        playno = br.ReadByte(),
                                        TPA = br.ReadByte(),
                                        PAS = br.ReadByte(),
                                        GS = br.ReadByte(),
                                        BF = br.ReadByte(),
                                        IP = br.ReadByte(),
                                        FGBP = br.ReadByte(),
                                        PRF = br.ReadByte(),
                                        TPAPer = br.ReadInt16(),
                                        PASPer = br.ReadInt16(),
                                        GSPer = br.ReadInt16(),
                                        BFPer = br.ReadInt16(),
                                        IPPer = br.ReadInt16(),
                                        FGBPPer = br.ReadInt16(),
                                        PRFPer = br.ReadInt16(),
                                        Stage = br.ReadByte(),
                                        Unk9a = br.ReadByte(),
                                        LGYear = br.ReadInt16(),
                                        LGMonth = br.ReadByte(),
                                        LGDay = br.ReadByte(),
                                        Ex1 = br.ReadByte(),
                                        Ex2 = br.ReadByte(),
                                        Unk10 = br.ReadBytes(20),//34
                                        A1 = br.ReadByte(),
                                        A2 = br.ReadByte(),
                                        A3 = br.ReadByte(),
                                        A4 = br.ReadByte(),
                                        DivP = br.ReadByte(),
                                        CS = br.ReadByte(),
                                        WSGT = br.ReadByte(),
                                        Ax4 = br.ReadByte(),
                                    });
                                }
                            }
                            br.Close();
                        }
                    }

                    catch (System.IO.EndOfStreamException e)
                    {
                        var lbl = "Error: " + e.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }

                    catch (Exception ex)
                    {
                        var lbl = "Error: " + ex.ToString();
                        PopUpEr pu = new PopUpEr(lbl);
                        pu.ShowDialog();
                        pu.Close();
                    }

                }

            }
            else  /// no organizations
            {
                return null;
            }
            return readList;
        }

        public void GETIDX(string path)
        {
            List<IDX> readList = new List<IDX>();

            if (path != null)
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        var row = 0;
                        br.BaseStream.Position = 0;
                        while (br.BaseStream.Position < 1200)
                        {
                            row++;
                            readList.Add(new IDX
                            {
                                A1 = br.ReadInt32(),
                                A2 = br.ReadInt16(),
                                A3 = br.ReadInt16(),
                                A4 = br.ReadInt16(),
                                A5 = br.ReadInt16(),
                                A6 = br.ReadInt16(),
                                A7 = br.ReadInt16(),
                                A8 = br.ReadInt16(),
                                A9 = br.ReadInt16(),
                                A10 = br.ReadInt16(),
                                B1 = br.ReadInt16(),
                            });
                        }
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                    return;
                }
            }
            RC = readList[1].A1;
            Ind = readList[43].A5;
        }

        public void GETIDXONEA(string path)// gets record count
        {
            if (path != null)
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        br.BaseStream.Position = 24;
                        RC = br.ReadInt16();
                        br.BaseStream.Position = 1042;
                        Ind = br.ReadInt32();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
        }

        public void GETIDXONE(string path, int Start)
        {
            datlist.Clear();
            if (path != null)
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        var row = 0;
                        br.BaseStream.Position = Start; // 1042;
                        while (br.BaseStream.Position < br.BaseStream.Length && row < RC)
                        {
                            row++;
                            datlist.Add(new IDXONE
                            {
                                A1 = br.ReadInt32(),
                                A2 = br.ReadByte(),
                                A3 = br.ReadByte(),
                            });
                        }
                        br.Close();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            //Ind = readList[43].A3;
        }

        public List<encPlstats> encplstats(string path, int UID = 0)
        {
            List<encPlstats> readList = new List<encPlstats>();
            var dpath = path + "\\encplstats.dat";
            try
            {
                using (BinaryReader br = new BinaryReader(new FileStream(dpath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //310 bytes
                {
                    br.BaseStream.Position = 2752;// 2752;
                    while (br.BaseStream.Position < br.BaseStream.Length - 2744)  //343 344
                    {
                        readList.Add(new encPlstats
                        {
                            st1 = br.ReadByte(),
                            st1a = br.ReadByte(),
                            st2 = br.ReadByte(),
                            SeasonID = br.ReadByte(),
                            UID = br.ReadInt32(),
                            type = br.ReadByte(),
                            RC = br.ReadByte(),
                            Year = br.ReadInt16(),
                            tmUID = br.ReadByte(),
                            st7a = br.ReadByte(),
                            st8 = br.ReadByte(),
                            st8a = br.ReadByte(),
                            fname = br.ReadBytes(16),
                            lname = br.ReadBytes(16),
                            role = br.ReadByte(),
                            bats = br.ReadByte(),
                            throws = br.ReadByte(),
                            ppos = br.ReadByte(), // 1= c 2 = 1b
                            st27 = br.ReadByte(),
                            st27a = br.ReadByte(),
                            st28 = br.ReadByte(),
                            st28a = br.ReadByte(),
                            st29 = br.ReadByte(),
                            st29a = br.ReadByte(),
                            ab = br.ReadInt16(),
                            r = br.ReadInt16(),
                            rbi = br.ReadInt16(),
                            hits = br.ReadInt16(),
                            dou = br.ReadByte(),
                            tri = br.ReadByte(),
                            hr = br.ReadByte(),
                            hbp = br.ReadByte(),
                            so = br.ReadInt16(),
                            bb = br.ReadInt16(),
                            iw = br.ReadByte(),
                            sb = br.ReadByte(),
                            cs = br.ReadByte(),
                            gw = br.ReadByte(),
                            sh = br.ReadByte(),
                            sf = br.ReadByte(),
                            gdp = br.ReadByte(),
                            g = br.ReadByte(),
                            gs = br.ReadByte(),
                            ci = br.ReadByte(),
                            vlab = br.ReadInt16(),
                            vlhits = br.ReadInt16(),
                            vl2b = br.ReadByte(),
                            vl3b = br.ReadByte(),
                            vlhr = br.ReadByte(),
                            vlrbi = br.ReadByte(),
                            vlhbp = br.ReadByte(),
                            vlbb = br.ReadByte(),
                            vlso = br.ReadInt16(),
                            vlsh = br.ReadByte(),
                            vlci = br.ReadByte(),
                            vlsf = br.ReadByte(),
                            vliw = br.ReadByte(),
                            vlgdp = br.ReadByte(),
                            vlgdp1 = br.ReadByte(),
                            vrab = br.ReadInt16(),
                            vrhits = br.ReadInt16(),
                            vr2b = br.ReadByte(),
                            vr3b = br.ReadByte(),
                            vrhr = br.ReadByte(),
                            vrrbi = br.ReadByte(),
                            vrhbp = br.ReadByte(),
                            vrbb = br.ReadByte(),
                            vrso = br.ReadInt16(),
                            vrsh = br.ReadByte(),
                            vrci = br.ReadByte(),
                            vrsf = br.ReadByte(),
                            vriw = br.ReadByte(),
                            vrgdp = br.ReadByte(),
                            vrgdp1 = br.ReadByte(),
                            currenthitstreak = br.ReadByte(),
                            longesthitstreak = br.ReadByte(),
                            pbf = br.ReadInt16(),
                            InnOuts = br.ReadInt16(),
                            pbab = br.ReadInt16(),
                            PHits = br.ReadInt16(),
                            PSO = br.ReadInt16(),
                            PBB = br.ReadInt16(),
                            piw = br.ReadByte(),
                            phbp = br.ReadByte(),
                            PR = br.ReadInt16(),
                            PER = br.ReadInt16(),
                            p2b = br.ReadByte(),
                            p3b = br.ReadByte(),
                            phr = br.ReadByte(),
                            pwp = br.ReadByte(),
                            pbk = br.ReadByte(),
                            psh = br.ReadByte(),
                            psf = br.ReadByte(),
                            st74a = br.ReadByte(),
                            pgdp = br.ReadByte(),
                            pw = br.ReadByte(),
                            pl = br.ReadByte(),
                            psaves = br.ReadByte(),
                            psaveopp = br.ReadByte(),
                            pblownsaves = br.ReadByte(),
                            pholds = br.ReadByte(),
                            pqs = br.ReadByte(),
                            prs = br.ReadInt16(),
                            pir = br.ReadByte(),
                            pirs = br.ReadByte(),
                            prl = br.ReadByte(),
                            prls = br.ReadByte(),
                            psho = br.ReadByte(),
                            pcg = br.ReadByte(),
                            pg = br.ReadByte(),
                            pgf = br.ReadByte(),
                            pgs = br.ReadByte(),
                            psb = br.ReadByte(),
                            pcs = br.ReadByte(),
                            pickoffs = br.ReadByte(),
                            pvlab = br.ReadInt16(),
                            pvlhits = br.ReadInt16(),
                            pvl2b = br.ReadByte(),
                            pvl3b = br.ReadByte(),
                            pvlhr = br.ReadByte(),
                            pvlrbi = br.ReadByte(),
                            pvlhbp = br.ReadByte(),
                            pvlbb = br.ReadByte(),
                            pvlso = br.ReadInt16(),
                            pvlsh = br.ReadByte(),
                            pvlci = br.ReadByte(),
                            pvlsf = br.ReadByte(),
                            pvliw = br.ReadByte(),
                            pvlgdp = br.ReadByte(),
                            pvlgdp1 = br.ReadByte(),
                            pvrab = br.ReadInt16(),
                            pvrhits = br.ReadInt16(),
                            pvr2b = br.ReadByte(),
                            pvr3b = br.ReadByte(),
                            pvrhr = br.ReadByte(),
                            pvrrbi = br.ReadByte(),
                            pvrhbp = br.ReadByte(),
                            pvrbb = br.ReadByte(),
                            pvrso = br.ReadInt16(),
                            pvrsh = br.ReadByte(),
                            pvrci = br.ReadByte(),
                            pvrsf = br.ReadByte(),
                            pvriw = br.ReadByte(),
                            pvrgdp = br.ReadByte(),
                            pvrgdp1 = br.ReadByte(),
                            pickoffthrows = br.ReadInt16(),
                            pthbp = br.ReadByte(),
                            st105a = br.ReadByte(),
                            intentionalballs = br.ReadInt16(),
                            balls = br.ReadInt16(),
                            calledstrikes = br.ReadInt16(),
                            swingingstrikes = br.ReadInt16(),
                            fouls = br.ReadInt16(),
                            inplay = br.ReadInt16(),
                            pop = br.ReadInt16(),
                            poc = br.ReadInt16(),
                            po1b = br.ReadInt16(),
                            po2b = br.ReadInt16(),
                            po3b = br.ReadInt16(),
                            poss = br.ReadInt16(),
                            polf = br.ReadInt16(),
                            pocf = br.ReadInt16(),
                            porf = br.ReadInt16(),
                            ap = br.ReadInt16(),
                            ac = br.ReadInt16(),
                            a1b = br.ReadInt16(),
                            a2b = br.ReadInt16(),
                            a3b = br.ReadInt16(),
                            ass = br.ReadInt16(),
                            alf = br.ReadInt16(),
                            acf = br.ReadInt16(),
                            arf = br.ReadInt16(),
                            ep = br.ReadByte(),
                            ec = br.ReadByte(),
                            e1b = br.ReadByte(),
                            e2b = br.ReadByte(),
                            e3b = br.ReadByte(),
                            ess = br.ReadByte(),
                            elf = br.ReadByte(),
                            ecf = br.ReadByte(),
                            erf = br.ReadByte(),
                            gp = br.ReadByte(),
                            gc = br.ReadByte(),
                            g1b = br.ReadByte(),
                            g2b = br.ReadByte(),
                            g3b = br.ReadByte(),
                            gss = br.ReadByte(),
                            glf = br.ReadByte(),
                            gcf = br.ReadByte(),
                            grf = br.ReadByte(),
                            outsp = br.ReadInt16(),
                            outsc = br.ReadInt16(),
                            outs1b = br.ReadInt16(),
                            outs2b = br.ReadInt16(),
                            outs3b = br.ReadInt16(),
                            outsss = br.ReadInt16(),
                            outslf = br.ReadInt16(),
                            outscf = br.ReadInt16(),
                            outsrf = br.ReadInt16(),
                            dpp = br.ReadInt16(),
                            dpc = br.ReadInt16(),
                            dp1b = br.ReadInt16(),
                            dp2b = br.ReadInt16(),
                            dp3b = br.ReadInt16(),
                            dpss = br.ReadInt16(),
                            dplf = br.ReadInt16(),
                            dpcf = br.ReadInt16(),
                            dprf = br.ReadInt16(),
                            gsp = br.ReadByte(),
                            gsc = br.ReadByte(),
                            gs1b = br.ReadByte(),
                            gs2b = br.ReadByte(),
                            gs3b = br.ReadByte(),
                            gsss = br.ReadByte(),
                            gslf = br.ReadByte(),
                            gscf = br.ReadByte(),
                            gsrf = br.ReadByte(),
                            cpb = br.ReadByte(),
                            csb = br.ReadByte(),
                            ccs = br.ReadByte(),
                            cpickoffs = br.ReadByte(),
                            cpickoffs1 = br.ReadByte(),
                            gsvlc = br.ReadByte(),
                            gsvl1b = br.ReadByte(),
                            gsvl2b = br.ReadByte(),
                            gsvl3b = br.ReadByte(),
                            gsvlss = br.ReadByte(),
                            gsvllf = br.ReadByte(),
                            gsvlcf = br.ReadByte(),
                            gsvlrf = br.ReadByte(),
                            gsvldh = br.ReadByte(),
                            gsvrc = br.ReadByte(),
                            gsvr1b = br.ReadByte(),
                            gsvr2b = br.ReadByte(),
                            gsvr3b = br.ReadByte(),
                            gsvrss = br.ReadByte(),
                            gsvrlf = br.ReadByte(),
                            gsvrcf = br.ReadByte(),
                            gsvrrf = br.ReadByte(),
                            gsvrdh = br.ReadByte(),
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            var tre = readList.Where(x => x.st1 == 255).ToList();// deleted entries?

            if (UID != 0)
            {
                readList = readList.Where(x => x.UID == UID).ToList();
                return readList;
            }
            else
            {
                readList = readList.OrderBy(x => x.UID).ToList();
                var ded = readList.Where(x => x.tmUID != 255).ToList();
                return ded;
            }

        }

        public List<Plyr> plyrload(string path)
        {
            var ipath = path + "\\encplyr.idx";
            if (ipath != null)
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(ipath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        br.BaseStream.Position = 24;//st13
                        RC = br.ReadInt16();
                        br.BaseStream.Position = 1074;//st18
                        Ind = br.ReadInt16();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }


            List<Plyr> readList = new List<Plyr>();
            try
            {
                var apath = path + "\\encplyr.dat";
                using (BinaryReader br = new BinaryReader(new FileStream(apath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //310 bytes
                {
                    var start = 2290;
                    br.BaseStream.Position = start;
                    RC = RC * 52 + start;
                    while (br.BaseStream.Position < RC) //971 records
                    {
                        readList.Add(new Plyr
                        {
                            st1 = br.ReadByte(),
                            st1a = br.ReadByte(),
                            UID = br.ReadInt32(),
                            st3 = br.ReadBytes(16),
                            st12 = br.ReadBytes(16),
                            BYear = br.ReadInt16(),
                            Bmonth = br.ReadByte(),
                            Bday = br.ReadByte(),
                            NRole = br.ReadByte(),
                            NBats = br.ReadByte(),
                            NThrows = br.ReadByte(),
                            NPPOS = br.ReadByte(),
                            FirstYear = br.ReadInt16(),
                            LastYear = br.ReadInt16(),
                            st27 = br.ReadByte(),
                            st28 = br.ReadByte(),
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            return readList;
        }

        public List<encteam> teamload(string path)
        {
            var apath = path + "\\encteam.dat";
            List<encteam> readList = new List<encteam>();
            List<encteam> newreadList = new List<encteam>();
            try
            {
                using (BinaryReader br = new BinaryReader(new FileStream(apath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //310 bytes
                {
                    var start = 2294;
                    br.BaseStream.Position = start;
                    RC = RC * 56 + start;
                    while (br.BaseStream.Position < br.BaseStream.Length - 55)
                    {
                        readList.Add(new encteam
                        {
                            st5 = br.ReadByte(),
                            st6 = br.ReadByte(),
                            st7 = br.ReadByte(),
                            st8 = br.ReadByte(),
                            tmID = br.ReadByte(),
                            st10 = br.ReadByte(),
                            abr = br.ReadBytes(3),
                            tmname = br.ReadBytes(43),
                            FirstYear = br.ReadInt16(),
                            LastYear = br.ReadInt16(),
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
                return null;
            }
            readList = readList.Where(x => x.st7 == 0).ToList();
            return readList;
        }

        public List<EncLgyr11> enclgyr11(string path)
        {
            var ipath = path + "\\enclgyr.idx";
            if (ipath != null)
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(ipath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        br.BaseStream.Position = 24;//st13
                        RC = br.ReadInt16();
                        if (RC < 0)
                        {
                            br.BaseStream.Position = 26;
                            RC = br.ReadInt16();
                        }
                        br.BaseStream.Position = 1186;//st18
                        Ind = br.ReadInt16();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            List<EncLgyr11> readList = new List<EncLgyr11>();
            try
            {
                path += "\\enclgyr.dat";
                var start = 5000;
                using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1000 bytes
                {
                    br.BaseStream.Position = start;
                    while (br.BaseStream.Position < br.BaseStream.Length - 999)
                    {
                        readList.Add(new EncLgyr11
                        {
                            st1 = br.ReadInt16(),
                            st2 = br.ReadByte(),
                            st2a = br.ReadByte(),
                            lgName = br.ReadByte(),
                            st3a = br.ReadByte(),
                            Year = br.ReadInt16(),
                            st5 = br.ReadByte(),
                            st5a = br.ReadByte(),
                            st6 = br.ReadByte(),
                            st6a = br.ReadByte(),
                            st7 = br.ReadByte(),
                            st7a = br.ReadByte(),
                            st8 = br.ReadBytes(118),
                            Teams = br.ReadBytes(128),
                            Games = br.ReadByte(),
                            st41 = br.ReadBytes(739),
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            readList = readList.Where(x => x.Year != -1).ToList();
            return readList;
        }

        public List<EncLgyr11> enclgyr12(string path)
        {
            var ipath = path + "\\enclgyr.idx";
            if (ipath != null)
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(ipath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        br.BaseStream.Position = 24;//st13
                        RC = br.ReadInt16();
                        if (RC < 0)
                        {
                            br.BaseStream.Position = 26;
                            RC = br.ReadInt16();
                        }
                        br.BaseStream.Position = 1186;//st18
                        Ind = br.ReadInt16();
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            List<EncLgyr11> readList = new List<EncLgyr11>();
            try
            {
                path += "\\enclgyr.dat";
                var start = 4512;
                using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1000 bytes
                {
                    br.BaseStream.Position = start;
                    while (br.BaseStream.Position < br.BaseStream.Length - 999)
                    {
                        readList.Add(new EncLgyr11
                        {
                            st1 = br.ReadInt16(),
                            st2 = br.ReadByte(),
                            st2a = br.ReadByte(),
                            lgName = br.ReadByte(),
                            st3a = br.ReadByte(),
                            Year = br.ReadInt16(),
                            st5 = br.ReadByte(),
                            st5a = br.ReadByte(),
                            st6 = br.ReadByte(),
                            st6a = br.ReadByte(),
                            st7 = br.ReadByte(),
                            st7a = br.ReadByte(),
                            st8 = br.ReadBytes(118),
                            Teams = br.ReadBytes(128),
                            Games = br.ReadByte(),
                            st41 = br.ReadBytes(867),
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            readList = readList.Where(x => x.Year != -1).ToList();
            return readList;
        }

        public List<encleag> encleag(string path)
        {
            var ipath = path + "\\encleag.idx";
            if (ipath != null)
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(ipath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                    {
                        br.BaseStream.Position = 24;//st13
                        RC = br.ReadInt16();
                        if (RC < 0)
                        {
                            br.BaseStream.Position = 26;
                            RC = br.ReadInt16();
                        }
                        br.BaseStream.Position = 1186;//st18
                        Ind = br.ReadInt16();
                        //Ind = Ind - 9;
                    }
                }

                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }
            List<encleag> readList = new List<encleag>();
            try
            {
                path += "\\encleag.dat";
                var start = 2252;
                using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //310 bytes
                {
                    br.BaseStream.Position = start;
                    RC = RC * 50 + start;
                    while (br.BaseStream.Position < RC)
                    {
                        readList.Add(new encleag
                        {
                            UID = br.ReadByte(),
                            st2 = br.ReadByte(),
                            LeagName = br.ReadBytes(39),
                            st42 = br.ReadByte(),
                            FirstYear = br.ReadInt16(),
                            LastYear = br.ReadInt16(),
                            OrgID = br.ReadByte(),
                            st48 = br.ReadByte(),
                            st49 = br.ReadByte(),
                            st50 = br.ReadByte(),
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            return readList;
        }

        public List<OrgYears> orgload(string path)
        {
            path += @"\encorg.dat";
            List<OrgYears> readList = new List<OrgYears>();
            try
            {
                using (BinaryReader br = new BinaryReader(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //310 bytes
                {
                    br.BaseStream.Position = 2294;
                    while (br.BaseStream.Position < 2298)
                    {
                        readList.Add(new OrgYears
                        {
                            FirstYear = br.ReadInt16(),
                            LastYear = br.ReadInt16(),
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                var lbl = "Error: " + ex.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
            return readList;
        }

        public List<GBG> Gamelogs(string path)
        {
            var sendpath = path + "\\DMBGBG.IDX";
            GETIDX(sendpath);
            List<GBG> readList = new List<GBG>();
            var bpath = path + "\\DMBGBG.DAT";
            if (bpath != null)
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(bpath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))// 300 bytes
                    {
                        br.BaseStream.Position = 2700;
                        var Iter = RC * 300 + 2700;
                        while (br.BaseStream.Position < Iter)//300
                        {
                            if (br.BaseStream.Position == 1535702)
                            {
                            }
                            readList.Add(new GBG
                            {
                                sw30 = br.ReadByte(),
                                sw31 = br.ReadByte(),
                                Year = br.ReadInt16(),//38
                                Month = br.ReadByte(),//70
                                Day = br.ReadByte(),
                                HomeTeamID = br.ReadInt16(),
                                VisTeamID = br.ReadInt16(),
                                GameOfDay = br.ReadByte(),
                                GameType = br.ReadByte(),
                                GStatsID = br.ReadInt16(),//PlayNum
                                TeamNo = br.ReadByte(),
                                TeamNoa = br.ReadByte(),
                                unk1 = br.ReadInt16(),
                                unk2 = br.ReadInt16(),
                                ParkUID = br.ReadInt16(),
                                BattOrdPos = br.ReadByte(),
                                PriPOS = br.ReadByte(), // 1 = P 2 = C ...
                                Role = br.ReadByte(),
                                InnEnter = br.ReadByte(),
                                T4a = br.ReadByte(),
                                T4b = br.ReadByte(),
                                T5 = br.ReadByte(),
                                T6 = br.ReadByte(),
                                T7 = br.ReadByte(),
                                T7a = br.ReadByte(),
                                T8 = br.ReadByte(),
                                T9 = br.ReadByte(),
                                AB = br.ReadInt16(),
                                Runs = br.ReadInt16(),
                                RBI = br.ReadInt16(),
                                Hits = br.ReadInt16(),
                                Dou = br.ReadByte(),
                                Tri = br.ReadByte(),
                                HR = br.ReadByte(),
                                HBP = br.ReadByte(),
                                SO = br.ReadByte(),
                                U8 = br.ReadByte(),
                                BB = br.ReadByte(),
                                U10 = br.ReadByte(),
                                IW = br.ReadByte(),
                                SB = br.ReadByte(),//50
                                CS = br.ReadByte(),
                                GWRBI = br.ReadByte(),
                                SH = br.ReadByte(),
                                SF = br.ReadByte(),
                                GIDP = br.ReadByte(),
                                G = br.ReadByte(),
                                GS = br.ReadByte(),
                                GS1 = br.ReadByte(),
                                ABVL = br.ReadInt16(),
                                HVL = br.ReadInt16(),
                                DVL = br.ReadByte(),
                                TVL = br.ReadByte(),
                                HRVL = br.ReadByte(),
                                RBIVL = br.ReadByte(),
                                HBPVL = br.ReadByte(),
                                BBVL = br.ReadByte(),
                                SOVL = br.ReadByte(),
                                w1a = br.ReadByte(),
                                SHVL = br.ReadByte(),
                                CIVL = br.ReadByte(),
                                SFVL = br.ReadByte(),
                                IWVL = br.ReadByte(),
                                DPVL = br.ReadByte(),
                                DPVL1 = br.ReadByte(),
                                ABVR = br.ReadInt16(),
                                HVR = br.ReadInt16(),
                                DVR = br.ReadByte(),
                                TVR = br.ReadByte(),
                                HRVR = br.ReadByte(),
                                RBIVR = br.ReadByte(),
                                HBPVR = br.ReadByte(),
                                BBVR = br.ReadByte(),
                                SOVR = br.ReadByte(),
                                w10a = br.ReadByte(),
                                SHVR = br.ReadByte(),
                                CIVR = br.ReadByte(),
                                SFVR = br.ReadByte(),
                                IWVR = br.ReadByte(),
                                DPVR = br.ReadByte(),
                                DPVR1 = br.ReadByte(),
                                PBF = br.ReadInt16(),
                                POuts = br.ReadInt16(),
                                PBFA = br.ReadInt16(),//50
                                PH = br.ReadInt16(),
                                PSO = br.ReadInt16(),
                                PBB = br.ReadInt16(),
                                PIW = br.ReadByte(),
                                PHBP = br.ReadByte(),
                                PR = br.ReadByte(),
                                PCI = br.ReadByte(),
                                PER = br.ReadByte(),
                                y4 = br.ReadByte(),
                                PD = br.ReadByte(),
                                PT = br.ReadByte(),
                                PHR = br.ReadByte(),
                                PWP = br.ReadByte(),
                                PBK = br.ReadByte(),
                                PSH = br.ReadByte(),
                                PSF = br.ReadByte(),
                                y2 = br.ReadByte(),
                                PDP = br.ReadByte(),
                                PWin = br.ReadByte(),
                                PLoss = br.ReadByte(),
                                PSV = br.ReadByte(),
                                PSVO = br.ReadByte(),
                                PBS = br.ReadByte(),
                                PHold = br.ReadByte(),
                                PQS = br.ReadByte(),
                                PRS = br.ReadByte(),
                                z2 = br.ReadByte(),
                                PIR = br.ReadByte(),
                                PIRS = br.ReadByte(),
                                PRL = br.ReadByte(),
                                PRLS = br.ReadByte(),
                                PSHO = br.ReadByte(),
                                PCG = br.ReadByte(),
                                PGP = br.ReadByte(),
                                PGF = br.ReadByte(),
                                PGS = br.ReadByte(),
                                PSB = br.ReadByte(),
                                PCS = br.ReadByte(),
                                PPO = br.ReadByte(),
                                pvlab = br.ReadInt16(),
                                pvlhits = br.ReadInt16(),
                                pvl2b = br.ReadByte(),
                                pvl3b = br.ReadByte(),
                                pvlhr = br.ReadByte(),
                                pvlrbi = br.ReadByte(),//50
                                pvlhbp = br.ReadByte(),
                                pvlbb = br.ReadByte(),
                                pvlso = br.ReadByte(),
                                st6 = br.ReadByte(),
                                pvlsh = br.ReadByte(),
                                pvlci = br.ReadByte(),
                                pvlsf = br.ReadByte(),
                                pvlibb = br.ReadByte(),
                                pvlgdp = br.ReadByte(),
                                st12 = br.ReadByte(),
                                pvrab = br.ReadInt16(),
                                pvrhits = br.ReadInt16(),
                                pvr2b = br.ReadByte(),
                                pvr3b = br.ReadByte(),
                                pvrhr = br.ReadByte(),
                                pvrrbi = br.ReadByte(),
                                pvrhbp = br.ReadByte(),
                                pvrbb = br.ReadByte(),
                                pvrso = br.ReadByte(),
                                st24 = br.ReadByte(),
                                pvrsh = br.ReadByte(),
                                pvrci = br.ReadByte(),
                                pvrsf = br.ReadByte(),
                                pvribb = br.ReadByte(),
                                pvrgdp = br.ReadByte(),
                                st30 = br.ReadByte(),
                                st31 = br.ReadByte(),
                                st32 = br.ReadByte(),
                                st33 = br.ReadByte(),
                                st34 = br.ReadByte(),
                                st35 = br.ReadByte(),
                                st36 = br.ReadByte(),
                                balls = br.ReadInt16(),
                                strike1 = br.ReadInt16(),
                                strike2 = br.ReadInt16(),
                                strike3 = br.ReadInt16(),
                                strike4 = br.ReadInt16(),
                                fpo1 = br.ReadInt16(),
                                fpo2 = br.ReadInt16(),
                                fpo3 = br.ReadInt16(),//50
                                fpo4 = br.ReadInt16(),
                                fpo5 = br.ReadInt16(),
                                fpo6 = br.ReadInt16(),
                                fpo7 = br.ReadInt16(),
                                fpo8 = br.ReadInt16(),
                                fpo9 = br.ReadInt16(),
                                fa1 = br.ReadInt16(),
                                fa2 = br.ReadInt16(),
                                fa3 = br.ReadInt16(),
                                fa4 = br.ReadInt16(),
                                fa5 = br.ReadInt16(),
                                fa6 = br.ReadInt16(),
                                fa7 = br.ReadInt16(),
                                fa8 = br.ReadInt16(),
                                fa9 = br.ReadInt16(),
                                fe1 = br.ReadByte(),
                                fe2 = br.ReadByte(),
                                fe3 = br.ReadByte(),
                                fe4 = br.ReadByte(),
                                fe5 = br.ReadByte(),
                                fe6 = br.ReadByte(),
                                fe7 = br.ReadByte(),
                                fe8 = br.ReadByte(),
                                fe9 = br.ReadByte(),
                                fg1 = br.ReadByte(),
                                fg2 = br.ReadByte(),
                                fg3 = br.ReadByte(),
                                fg4 = br.ReadByte(),
                                fg5 = br.ReadByte(),
                                fg6 = br.ReadByte(),
                                fg7 = br.ReadByte(),
                                fg8 = br.ReadByte(),
                                fg9 = br.ReadByte(),
                                fouts1 = br.ReadInt16(),//50
                                fouts2 = br.ReadInt16(),
                                fouts3 = br.ReadInt16(),
                                fouts4 = br.ReadInt16(),
                                fouts5 = br.ReadInt16(),
                                fouts6 = br.ReadInt16(),
                                fouts7 = br.ReadInt16(),
                                fouts8 = br.ReadInt16(),
                                fouts9 = br.ReadInt16(),
                                fgdp1 = br.ReadInt16(),
                                fgdp2 = br.ReadInt16(),
                                fgdp3 = br.ReadInt16(),
                                fgdp4 = br.ReadInt16(),
                                fgdp5 = br.ReadInt16(),
                                fgdp6 = br.ReadInt16(),
                                fgdp7 = br.ReadInt16(),
                                fgdp8 = br.ReadInt16(),
                                fgdp9 = br.ReadInt16(),
                                fgs1 = br.ReadByte(),
                                fgs2 = br.ReadByte(),
                                fgs3 = br.ReadByte(),
                                fgs4 = br.ReadByte(),
                                fgs5 = br.ReadByte(),
                                fgs6 = br.ReadByte(),
                                fgs7 = br.ReadByte(),
                                fgs8 = br.ReadByte(),
                                fgs9 = br.ReadByte(),
                                fcpb = br.ReadByte(),
                                fcsb = br.ReadByte(),
                                fccs = br.ReadByte(),
                                fcpick = br.ReadByte(),
                                sw32 = br.ReadByte(),//50
                            });
                        }//while

                        br.Close();
                    }
                }
                catch (System.IO.EndOfStreamException e)
                {
                    var lbl = "Error: " + e.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }

                catch (Exception ex)
                {
                    var lbl = "Error: " + ex.ToString();
                    PopUpEr pu = new PopUpEr(lbl);
                    pu.ShowDialog();
                    pu.Close();
                }
            }//if
            var sta = readList.Where(x => x.StatusR != 0);
            return readList;
        }

        public IEnumerable<HighLights> MyHighlightsLoad(string path)
        {
            List<HighLights> binary = new List<HighLights>();
            string filename;
            if (path.Substring(path.Length - 3) == "dat") filename = path;
            else filename = path + "\\LeagueHighlights.dat";

            if (File.Exists(filename))
            {
                try
                {
                    using (BinaryReader br = new BinaryReader(new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))) //1076 
                        while (br.BaseStream.Position != br.BaseStream.Length)
                        {
                            binary.Add(new HighLights
                            {
                                Cat = br.ReadString(),
                                GSTatsID = br.ReadInt32(),
                                Date = Convert.ToDateTime(br.ReadString()),
                                SDate = br.ReadString(),
                                TeamNo = br.ReadInt32(),
                                Value = br.ReadString(),
                                GameType = br.ReadInt32(),
                                Entry = br.ReadString(),
                                Abbr = br.ReadString(),
                                OppAbbr = br.ReadString(),
                                GameOfDay = br.ReadInt32(),
                                FileName = br.ReadString(),
                            });
                        }
                }
                catch
                {
                }
            }
            return binary;
        }

        public void MyHighlightsSave(string path, List<HighLights> savelist)
        {
            var filename = path + "\\LeagueHighlights.dat";
            if (File.Exists(filename))
            {
                File.Delete(filename);
            }
            try
            {
                using (BinaryWriter bw = new BinaryWriter(new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))) //1076 
                    foreach (var i in savelist)
                    {
                        bw.Write(i.Cat);
                        bw.Write(i.GSTatsID);
                        bw.Write(i.Date.ToShortDateString());
                        bw.Write(i.SDate);
                        bw.Write(i.TeamNo);
                        bw.Write(i.Value);
                        bw.Write(i.GameType);
                        bw.Write(i.Entry == null ? "" : i.Entry);
                        bw.Write(i.Abbr == null ? "" : i.Abbr);
                        bw.Write(i.OppAbbr == null ? "" : i.OppAbbr);
                        bw.Write(i.GameOfDay);
                        bw.Write(i.FileName);
                    }
            }
            catch (Exception e)
            {
                var lbl = "Error: " + e.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
        }

        public void MyHighlightsSaveAppend(string path, List<HighLights> savelist)
        {
            var filename = path + "\\LeagueHighlights.dat";
            try
            {
                using (BinaryWriter bw = new BinaryWriter(new FileStream(filename, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))) //1076 
                    foreach (var i in savelist)
                    {
                        bw.Write(i.Cat);
                        bw.Write(i.GSTatsID);
                        bw.Write(i.Date.ToShortDateString());
                        bw.Write(i.SDate);
                        bw.Write(i.TeamNo);
                        bw.Write(i.Value);
                        bw.Write(i.GameType);
                        bw.Write(i.Entry == null ? "" : i.Entry);
                        bw.Write(i.Abbr == null ? "" : i.Abbr);
                        bw.Write(i.OppAbbr == null ? "" : i.OppAbbr);
                        bw.Write(i.GameOfDay);
                        bw.Write(i.FileName);
                    }
            }
            catch (Exception e)
            {
                var lbl = "Error: " + e.ToString();
                PopUpEr pu = new PopUpEr(lbl);
                pu.ShowDialog();
                pu.Close();
            }
        }
    }
}
